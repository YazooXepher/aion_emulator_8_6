-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: al_server_gs
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `abyss_rank`
--

DROP TABLE IF EXISTS `abyss_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abyss_rank` (
  `player_id` int(11) NOT NULL,
  `daily_ap` int(11) NOT NULL,
  `daily_gp` int(11) NOT NULL,
  `weekly_ap` int(11) NOT NULL,
  `weekly_gp` int(11) NOT NULL,
  `ap` int(11) NOT NULL,
  `gp` int(11) NOT NULL,
  `rank` int(2) NOT NULL DEFAULT 1,
  `top_ranking` int(4) NOT NULL,
  `daily_kill` int(5) NOT NULL,
  `weekly_kill` int(5) NOT NULL,
  `all_kill` int(4) NOT NULL DEFAULT 0,
  `max_rank` int(2) NOT NULL DEFAULT 1,
  `last_kill` int(5) NOT NULL,
  `last_ap` int(11) NOT NULL,
  `last_gp` int(11) NOT NULL,
  `last_update` decimal(20,0) NOT NULL,
  `rank_pos` int(11) NOT NULL DEFAULT 0,
  `old_rank_pos` int(11) NOT NULL DEFAULT 0,
  `rank_ap` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`),
  CONSTRAINT `abyss_rank_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abyss_rank`
--

LOCK TABLES `abyss_rank` WRITE;
/*!40000 ALTER TABLE `abyss_rank` DISABLE KEYS */;
INSERT INTO `abyss_rank` VALUES (105181,74,0,74,0,74,0,9,0,0,0,0,1,0,0,0,1785340800032,2,2,0),(105291,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,1785708000077,1,1,0);
/*!40000 ALTER TABLE `abyss_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_transform`
--

DROP TABLE IF EXISTS `account_transform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_transform` (
  `account_id` int(11) NOT NULL,
  `card_id` int(11) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_transform`
--

LOCK TABLES `account_transform` WRITE;
/*!40000 ALTER TABLE `account_transform` DISABLE KEYS */;
INSERT INTO `account_transform` VALUES (2,982010,1),(2,982056,2),(2,982026,1),(2,982025,1),(2,982059,1),(8,982109,1),(8,982074,2),(8,982107,1),(8,982108,1),(8,982110,1),(8,982111,1),(8,982112,1),(8,982113,1),(8,982114,1),(8,982115,1),(8,982105,1),(8,982106,1),(8,982116,1),(8,982117,1),(8,982118,1),(8,982119,1),(8,982120,1),(8,982121,1),(8,982122,1),(8,982123,1),(8,982127,1),(8,982128,1),(8,982129,1),(8,982130,1),(8,982131,1),(8,982132,1),(8,982133,1),(8,982134,1),(8,982135,1),(8,982136,1),(8,982137,1),(8,982138,1),(8,982139,1),(8,982140,1),(8,982141,1),(8,982142,1),(8,982143,1),(8,982144,1),(8,982145,1),(8,982146,1),(8,982147,1),(8,982148,1),(8,982149,1),(8,982047,1),(8,982094,1),(8,982044,1);
/*!40000 ALTER TABLE `account_transform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `announce` text NOT NULL,
  `faction` enum('ALL','ASMODIANS','ELYOS') NOT NULL DEFAULT 'ALL',
  `type` enum('SHOUT','ORANGE','YELLOW','WHITE','SYSTEM') NOT NULL DEFAULT 'SYSTEM',
  `delay` int(4) NOT NULL DEFAULT 1800,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `atreian_passports`
--

DROP TABLE IF EXISTS `atreian_passports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atreian_passports` (
  `account_id` int(11) NOT NULL,
  `passport_id` int(11) NOT NULL,
  `stamps` int(11) NOT NULL DEFAULT 0,
  `last_stamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rewarded` tinyint(1) NOT NULL DEFAULT 0,
  `available` int(1) DEFAULT NULL,
  UNIQUE KEY `account_passport` (`account_id`,`passport_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atreian_passports`
--

LOCK TABLES `atreian_passports` WRITE;
/*!40000 ALTER TABLE `atreian_passports` DISABLE KEYS */;
INSERT INTO `atreian_passports` VALUES (8,11,0,'2026-08-01 15:35:58',0,NULL);
/*!40000 ALTER TABLE `atreian_passports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banned_hdd`
--

DROP TABLE IF EXISTS `banned_hdd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banned_hdd` (
  `uniId` int(10) NOT NULL AUTO_INCREMENT,
  `hdd_serial` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `details` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uniId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banned_hdd`
--

LOCK TABLES `banned_hdd` WRITE;
/*!40000 ALTER TABLE `banned_hdd` DISABLE KEYS */;
/*!40000 ALTER TABLE `banned_hdd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `base_location`
--

DROP TABLE IF EXISTS `base_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `base_location` (
  `id` int(11) NOT NULL,
  `race` enum('ELYOS','ASMODIANS','NPC') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `base_location`
--

LOCK TABLES `base_location` WRITE;
/*!40000 ALTER TABLE `base_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `base_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocks` (
  `player` int(11) NOT NULL,
  `blocked_player` int(11) NOT NULL,
  `reason` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`player`,`blocked_player`),
  KEY `blocked_player` (`blocked_player`),
  CONSTRAINT `blocks_ibfk_1` FOREIGN KEY (`player`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `blocks_ibfk_2` FOREIGN KEY (`blocked_player`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocks`
--

LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookmark`
--

DROP TABLE IF EXISTS `bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookmark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `char_id` int(11) NOT NULL,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `world_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmark`
--

LOCK TABLES `bookmark` WRITE;
/*!40000 ALTER TABLE `bookmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `broker`
--

DROP TABLE IF EXISTS `broker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `broker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_pointer` int(11) NOT NULL DEFAULT 0,
  `item_id` int(11) NOT NULL,
  `item_count` bigint(20) NOT NULL,
  `item_creator` varchar(50) DEFAULT NULL,
  `seller` varchar(50) DEFAULT NULL,
  `price` bigint(20) NOT NULL DEFAULT 0,
  `broker_race` enum('ELYOS','ASMODIAN') NOT NULL,
  `expire_time` timestamp NOT NULL DEFAULT '2010-01-01 01:00:00',
  `settle_time` timestamp NOT NULL DEFAULT '2010-01-01 01:00:00',
  `seller_id` int(11) NOT NULL,
  `is_sold` tinyint(1) NOT NULL,
  `is_settled` tinyint(1) NOT NULL,
  `is_partsale` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `seller_id` (`seller_id`),
  CONSTRAINT `broker_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `players` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `broker`
--

LOCK TABLES `broker` WRITE;
/*!40000 ALTER TABLE `broker` DISABLE KEYS */;
/*!40000 ALTER TABLE `broker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenge_tasks`
--

DROP TABLE IF EXISTS `challenge_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_tasks` (
  `task_id` int(11) NOT NULL,
  `quest_id` int(10) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `owner_type` enum('LEGION','TOWN') NOT NULL,
  `complete_count` int(3) unsigned NOT NULL DEFAULT 0,
  `complete_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`task_id`,`quest_id`,`owner_id`,`owner_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge_tasks`
--

LOCK TABLES `challenge_tasks` WRITE;
/*!40000 ALTER TABLE `challenge_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `challenge_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craft_cooldowns`
--

DROP TABLE IF EXISTS `craft_cooldowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craft_cooldowns` (
  `player_id` int(11) NOT NULL,
  `delay_id` int(11) unsigned NOT NULL,
  `reuse_time` bigint(13) unsigned NOT NULL,
  PRIMARY KEY (`player_id`,`delay_id`),
  CONSTRAINT `craft_cooldowns_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craft_cooldowns`
--

LOCK TABLES `craft_cooldowns` WRITE;
/*!40000 ALTER TABLE `craft_cooldowns` DISABLE KEYS */;
/*!40000 ALTER TABLE `craft_cooldowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_items`
--

DROP TABLE IF EXISTS `event_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_items` (
  `player_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `counts` int(10) unsigned NOT NULL,
  PRIMARY KEY (`player_id`,`item_id`),
  CONSTRAINT `event_items_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_items`
--

LOCK TABLES `event_items` WRITE;
/*!40000 ALTER TABLE `event_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `f2paccount`
--

DROP TABLE IF EXISTS `f2paccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `f2paccount` (
  `account_id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `f2paccount`
--

LOCK TABLES `f2paccount` WRITE;
/*!40000 ALTER TABLE `f2paccount` DISABLE KEYS */;
/*!40000 ALTER TABLE `f2paccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friends`
--

DROP TABLE IF EXISTS `friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friends` (
  `player` int(11) NOT NULL,
  `friend` int(11) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`player`,`friend`),
  KEY `friend` (`friend`),
  CONSTRAINT `friends_ibfk_1` FOREIGN KEY (`player`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `friends_ibfk_2` FOREIGN KEY (`friend`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friends`
--

LOCK TABLES `friends` WRITE;
/*!40000 ALTER TABLE `friends` DISABLE KEYS */;
/*!40000 ALTER TABLE `friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guides`
--

DROP TABLE IF EXISTS `guides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guides` (
  `guide_id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) NOT NULL,
  `title` varchar(80) NOT NULL,
  PRIMARY KEY (`guide_id`),
  KEY `player_id` (`player_id`),
  CONSTRAINT `guides_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guides`
--

LOCK TABLES `guides` WRITE;
/*!40000 ALTER TABLE `guides` DISABLE KEYS */;
/*!40000 ALTER TABLE `guides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_quests`
--

DROP TABLE IF EXISTS `guild_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_quests` (
  `player_id` int(11) NOT NULL,
  `guild_id` int(2) NOT NULL DEFAULT 0,
  `recently_taken_quest` int(6) NOT NULL DEFAULT 0,
  `completion_timestamp` timestamp NULL DEFAULT NULL,
  `currently_started_quest` int(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`),
  CONSTRAINT `guild_quests_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_quests`
--

LOCK TABLES `guild_quests` WRITE;
/*!40000 ALTER TABLE `guild_quests` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_quests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `house_bids`
--

DROP TABLE IF EXISTS `house_bids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `house_bids` (
  `player_id` int(10) NOT NULL,
  `house_id` int(10) NOT NULL,
  `bid` bigint(20) NOT NULL,
  `bid_time` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`player_id`,`house_id`,`bid`),
  KEY `house_id_ibfk_1` (`house_id`),
  CONSTRAINT `house_id_ibfk_1` FOREIGN KEY (`house_id`) REFERENCES `houses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `house_bids`
--

LOCK TABLES `house_bids` WRITE;
/*!40000 ALTER TABLE `house_bids` DISABLE KEYS */;
INSERT INTO `house_bids` VALUES (0,11839,112000000,'2026-08-13 13:59:21'),(0,29611,112000000,'2026-08-13 13:59:21'),(0,50767,12000000,'2026-08-13 13:59:21'),(0,50775,112000000,'2026-08-13 13:59:21'),(0,50787,112000000,'2026-08-13 13:59:21'),(0,80766,12000000,'2026-08-13 13:59:21'),(0,80830,12000000,'2026-08-13 13:59:21'),(0,80946,12000000,'2026-08-13 13:59:21'),(0,80962,12000000,'2026-08-13 13:59:21'),(0,80966,12000000,'2026-08-13 13:59:21'),(0,80974,12000000,'2026-08-13 13:59:21'),(0,80986,12000000,'2026-08-13 13:59:21'),(0,80994,12000000,'2026-08-13 13:59:21'),(0,81010,12000000,'2026-08-13 13:59:21'),(0,81026,12000000,'2026-08-13 13:59:21'),(0,81050,12000000,'2026-08-13 13:59:21'),(0,81086,12000000,'2026-08-13 13:59:21'),(0,81122,12000000,'2026-08-13 13:59:21'),(0,81254,12000000,'2026-08-13 13:59:21'),(0,81390,12000000,'2026-08-13 13:59:21'),(0,81426,12000000,'2026-08-13 13:59:21'),(0,81510,12000000,'2026-08-13 13:59:21'),(0,81538,12000000,'2026-08-13 13:59:21'),(0,81590,12000000,'2026-08-13 13:59:21'),(0,81594,12000000,'2026-08-13 13:59:21'),(0,81690,335000000,'2026-08-13 13:59:21'),(0,81782,335000000,'2026-08-13 13:59:21'),(0,81790,335000000,'2026-08-13 13:59:21'),(0,82026,335000000,'2026-08-13 13:59:21'),(0,82042,335000000,'2026-08-13 13:59:21'),(0,82158,1000000000,'2026-08-13 13:59:21'),(0,82238,112000000,'2026-08-13 13:59:21'),(0,82242,112000000,'2026-08-13 13:59:21'),(0,82334,112000000,'2026-08-13 13:59:21'),(0,82458,112000000,'2026-08-13 13:59:21'),(0,82590,112000000,'2026-08-13 13:59:21'),(0,82626,112000000,'2026-08-13 13:59:21'),(0,82630,112000000,'2026-08-13 13:59:21'),(0,82694,112000000,'2026-08-13 13:59:21'),(0,84217,335000000,'2026-08-13 13:59:21'),(0,84241,335000000,'2026-08-13 13:59:21'),(0,84301,335000000,'2026-08-13 13:59:21'),(0,84397,335000000,'2026-08-13 13:59:21'),(0,84533,335000000,'2026-08-13 13:59:21'),(0,84661,12000000,'2026-08-13 13:59:21'),(0,84709,12000000,'2026-08-13 13:59:21'),(0,84749,12000000,'2026-08-13 13:59:21'),(0,84769,12000000,'2026-08-13 13:59:21'),(0,84773,12000000,'2026-08-13 13:59:21'),(0,84905,12000000,'2026-08-13 13:59:21'),(0,84921,12000000,'2026-08-13 13:59:21'),(0,84929,12000000,'2026-08-13 13:59:21'),(0,85077,12000000,'2026-08-13 13:59:21'),(0,85097,12000000,'2026-08-13 13:59:21'),(0,85109,12000000,'2026-08-13 13:59:21'),(0,85141,12000000,'2026-08-13 13:59:21'),(0,85161,12000000,'2026-08-13 13:59:21'),(0,85189,12000000,'2026-08-13 13:59:21'),(0,85249,12000000,'2026-08-13 13:59:21'),(0,85321,12000000,'2026-08-13 13:59:21'),(0,85357,12000000,'2026-08-13 13:59:21'),(0,85417,12000000,'2026-08-13 13:59:21'),(0,85469,12000000,'2026-08-13 13:59:21'),(0,85525,1000000000,'2026-08-13 13:59:21'),(0,85549,112000000,'2026-08-13 13:59:21'),(0,85553,112000000,'2026-08-13 13:59:21'),(0,85597,112000000,'2026-08-13 13:59:21'),(0,85625,112000000,'2026-08-13 13:59:21'),(0,85977,112000000,'2026-08-13 13:59:21'),(0,86013,112000000,'2026-08-13 13:59:21'),(0,86045,112000000,'2026-08-13 13:59:21'),(0,86057,112000000,'2026-08-13 13:59:21');
/*!40000 ALTER TABLE `house_bids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `house_object_cooldowns`
--

DROP TABLE IF EXISTS `house_object_cooldowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `house_object_cooldowns` (
  `player_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `reuse_time` bigint(20) NOT NULL,
  PRIMARY KEY (`player_id`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `house_object_cooldowns`
--

LOCK TABLES `house_object_cooldowns` WRITE;
/*!40000 ALTER TABLE `house_object_cooldowns` DISABLE KEYS */;
/*!40000 ALTER TABLE `house_object_cooldowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `house_scripts`
--

DROP TABLE IF EXISTS `house_scripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `house_scripts` (
  `house_id` int(11) NOT NULL,
  `index` tinyint(4) NOT NULL,
  `script` mediumtext DEFAULT NULL,
  PRIMARY KEY (`house_id`,`index`),
  CONSTRAINT `houses_id_ibfk_1` FOREIGN KEY (`house_id`) REFERENCES `houses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `house_scripts`
--

LOCK TABLES `house_scripts` WRITE;
/*!40000 ALTER TABLE `house_scripts` DISABLE KEYS */;
/*!40000 ALTER TABLE `house_scripts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `houses`
--

DROP TABLE IF EXISTS `houses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `houses` (
  `id` int(10) NOT NULL,
  `player_id` int(10) NOT NULL DEFAULT 0,
  `building_id` int(10) NOT NULL,
  `address` int(10) NOT NULL,
  `acquire_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `settings` int(11) NOT NULL DEFAULT 0,
  `status` enum('ACTIVE','SELL_WAIT','INACTIVE','NOSALE') NOT NULL DEFAULT 'ACTIVE',
  `fee_paid` tinyint(1) NOT NULL DEFAULT 1,
  `next_pay` timestamp NULL DEFAULT NULL,
  `sell_started` timestamp NULL DEFAULT NULL,
  `sign_notice` binary(130) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address` (`address`) USING BTREE,
  KEY `address_2` (`address`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `houses`
--

LOCK TABLES `houses` WRITE;
/*!40000 ALTER TABLE `houses` DISABLE KEYS */;
INSERT INTO `houses` VALUES (11839,0,352000,6003,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(29611,0,352000,6104,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(50767,0,353000,7009,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(50775,0,352000,7003,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(50787,0,352000,7007,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(80766,0,353000,10156,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(80830,0,353000,10217,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(80946,0,353000,10291,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(80962,0,353000,10295,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(80966,0,353000,10296,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(80974,0,353000,10306,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(80986,0,353000,10309,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(80994,0,353000,10311,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81010,0,353000,10315,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81026,0,353000,10326,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81050,0,353000,10332,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81086,0,353000,10347,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81122,0,353000,10356,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81254,0,353000,10396,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81390,0,353000,10433,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81426,0,353000,10442,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81510,0,353000,10463,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81538,0,353000,10470,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81590,0,353000,10483,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81594,0,353000,10484,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81690,0,351000,10011,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81782,0,351000,10039,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(81790,0,351000,10041,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(82026,0,351000,10145,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(82042,0,351000,10161,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(82158,0,350000,10002,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(82238,0,352000,10091,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(82242,0,352000,10092,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(82334,0,352000,10148,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(82458,0,352000,10208,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(82590,0,352000,10281,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(82626,0,352000,10302,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(82630,0,352000,10303,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(82694,0,352000,10360,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84217,0,351000,20039,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84241,0,351000,20045,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84301,0,351000,20067,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84397,0,351000,20118,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84533,0,351000,20202,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84661,0,353000,20195,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84709,0,353000,20234,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84749,0,353000,20256,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84769,0,353000,20272,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84773,0,353000,20273,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84905,0,353000,20330,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84921,0,353000,20334,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(84929,0,353000,20336,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85077,0,353000,20386,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85097,0,353000,20391,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85109,0,353000,20394,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85141,0,353000,20404,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85161,0,353000,20409,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85189,0,353000,20416,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85249,0,353000,20432,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85321,0,353000,20450,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85357,0,353000,20459,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85417,0,353000,20474,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85469,0,353000,20487,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85525,0,350000,20001,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85549,0,352000,20036,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85553,0,352000,20037,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85597,0,352000,20075,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85625,0,352000,20095,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(85977,0,352000,20285,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(86013,0,352000,20319,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(86045,0,352000,20341,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL),(86057,0,352000,20358,'2026-07-16 00:06:10',256,'SELL_WAIT',1,NULL,'2026-07-16 00:06:09',NULL);
/*!40000 ALTER TABLE `houses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `item_unique_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_count` bigint(20) NOT NULL DEFAULT 0,
  `item_color` int(11) NOT NULL DEFAULT 0,
  `color_expires` int(11) NOT NULL DEFAULT 0,
  `item_creator` varchar(50) DEFAULT NULL,
  `expire_time` int(11) NOT NULL DEFAULT 0,
  `activation_count` int(11) NOT NULL DEFAULT 0,
  `item_owner` int(11) NOT NULL,
  `is_equiped` tinyint(1) NOT NULL DEFAULT 0,
  `is_soul_bound` tinyint(1) NOT NULL DEFAULT 0,
  `slot` bigint(20) NOT NULL DEFAULT 0,
  `item_location` tinyint(1) DEFAULT 0,
  `enchant` tinyint(1) DEFAULT 0,
  `item_skin` int(11) NOT NULL DEFAULT 0,
  `fusioned_item` int(11) NOT NULL DEFAULT 0,
  `optional_socket` int(1) NOT NULL DEFAULT 0,
  `optional_fusion_socket` int(1) NOT NULL DEFAULT 0,
  `charge` mediumint(9) NOT NULL DEFAULT 0,
  `rnd_bonus` smallint(6) DEFAULT NULL,
  `rnd_count` smallint(6) NOT NULL DEFAULT 0,
  `pack_count` smallint(6) NOT NULL DEFAULT 0,
  `authorize` int(11) NOT NULL DEFAULT 0,
  `is_packed` tinyint(1) NOT NULL DEFAULT 0,
  `is_amplified` tinyint(1) NOT NULL DEFAULT 0,
  `buff_skill` int(11) NOT NULL DEFAULT 0,
  `reduction_level` int(11) NOT NULL,
  `luna_reskin` tinyint(1) NOT NULL DEFAULT 0,
  `isEnhance` tinyint(1) NOT NULL DEFAULT 0,
  `enhanceSkillId` int(11) NOT NULL DEFAULT 0,
  `enhanceSkillEnchant` int(11) NOT NULL DEFAULT 0,
  `is_seal` int(1) NOT NULL DEFAULT 0,
  `skin_skill` int(11) NOT NULL DEFAULT 0,
  `grind_socket` int(1) NOT NULL DEFAULT 0,
  `grind_color` int(11) NOT NULL DEFAULT 0,
  `grind_stone` bigint(20) NOT NULL DEFAULT 0,
  `grind_slot` int(10) NOT NULL DEFAULT 0,
  `contaminated` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_unique_id`),
  KEY `item_location` (`item_location`) USING HASH,
  KEY `index3` (`item_owner`,`item_location`,`is_equiped`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (105182,182400001,999832762,0,0,'',0,0,105181,0,0,65535,0,0,182400001,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105185,110150062,1,0,0,'',0,0,105181,1,0,8,0,0,110150062,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105186,113150062,1,0,0,'',0,0,105181,1,0,4096,0,0,113150062,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105187,111150062,1,0,0,'',0,0,105181,1,0,16,0,0,111150062,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105188,114150062,1,0,0,'',0,0,105181,1,0,32,0,0,114150062,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105190,169300002,30,0,0,'',0,0,105181,0,0,2,0,0,169300002,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105191,162005039,50,0,0,'',0,1,105181,0,0,3,0,0,162005039,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105192,162005040,50,0,0,'',0,1,105181,0,0,4,0,0,162005040,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105193,188071452,1,0,0,'',0,1,105291,0,0,11,0,0,188071452,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105208,162005000,11,0,0,'',0,1,105181,0,0,5,0,0,162005000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105209,162005004,8,0,0,'',0,1,105181,0,0,7,0,0,162005004,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105210,164020509,10,0,0,'',0,1,105291,0,0,10,0,0,164020509,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105212,160040083,7,0,0,'',0,1,105181,0,0,1,0,0,160040083,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105214,160002499,1,0,0,'',0,1,105291,0,0,20,0,0,160002499,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105215,190099000,8,0,0,'',0,1,105181,0,0,0,0,0,190099000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105216,190200000,50,0,0,'',0,0,105291,0,0,21,0,0,190200000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105217,166030013,1,0,0,'',0,1,105291,0,0,17,0,0,166030013,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105220,168000043,1,0,0,'',0,1,105291,0,0,19,0,0,168000043,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105221,152150002,1,0,0,'',0,0,105291,0,0,18,0,0,152150002,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105222,168000050,1,0,0,'',0,1,105291,0,0,16,0,0,168000050,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105223,140001122,1,0,0,'',0,0,105291,0,0,23,0,0,140001122,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105224,140001122,1,0,0,'',0,0,105291,0,0,25,0,0,140001122,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105227,100050319,1,0,0,'',0,0,105291,0,0,12,0,0,100050319,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105228,100050324,1,0,0,'',0,0,105291,0,0,13,0,0,100050324,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105276,164000010,1,0,0,'',0,1,105181,0,0,6,0,0,164000010,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105287,100150314,1,0,0,'',0,0,105291,1,0,1,0,0,100150314,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105288,115050485,1,0,0,'',0,0,105291,1,0,2,0,0,115050485,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105289,188071452,2,0,0,'',0,1,105181,0,0,13,0,0,188071452,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105290,164020509,10,0,0,'',0,1,105181,0,0,14,0,0,164020509,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105292,182400001,9999903833437,0,0,'',0,0,105291,0,0,65535,0,0,182400001,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105294,110550124,1,0,0,'',0,0,105291,1,0,8,0,0,110550124,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105295,113550124,1,0,0,'',0,0,105291,1,0,4096,0,0,113550124,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105296,111550124,1,0,0,'',0,0,105291,1,0,16,0,0,111550124,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105297,114550124,1,0,0,'',0,0,105291,1,0,32,0,0,114550124,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105298,160020008,10,0,0,'',0,1,105291,0,0,5,0,0,160020008,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105299,169300002,30,0,0,'',0,0,105291,0,0,6,0,0,169300002,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105300,162005039,50,0,0,'',0,1,105291,0,0,2,0,0,162005039,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105301,162005040,50,0,0,'',0,1,105291,0,0,3,0,0,162005040,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105317,162005000,11,0,0,'',0,1,105291,0,0,4,0,0,162005000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105319,160040083,7,0,0,'',0,1,105291,0,0,0,0,0,160040083,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105320,162005004,8,0,0,'',0,1,105291,0,0,1,0,0,162005004,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105387,152150002,1,0,0,'',0,0,105181,0,0,8,0,0,152150002,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105401,160020001,5,0,0,'',0,1,105181,0,0,11,0,0,160020001,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105409,100050319,1,0,0,'',0,0,105291,0,0,14,0,0,100050319,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105410,110150339,1,0,0,'',0,0,105291,0,0,15,0,0,110150339,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105473,160020000,5,0,0,'',0,1,105291,0,0,7,0,0,160020000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105476,162002024,6,0,0,'',0,1,105181,0,0,10,0,0,162002024,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105477,164002116,1,0,0,'',0,1,105181,0,0,12,0,0,164002116,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105502,102220104,1,0,0,'',0,0,105181,1,0,3,0,0,102220104,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105563,162002024,3,0,0,'',0,1,105291,0,0,8,0,0,162002024,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105564,164002116,1,0,0,'',0,1,105291,0,0,9,0,0,164002116,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105636,188072933,1,0,0,'',0,1,105181,0,0,9,0,0,188072933,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105695,166023100,28,0,0,'',0,1,105291,0,0,24,0,0,166023100,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105696,188059062,10,0,0,'',0,1,105291,0,0,26,0,0,188059062,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105698,110905146,1,0,0,'',0,0,105291,0,0,28,0,0,110905146,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105699,110905146,1,0,0,'',0,0,105291,0,0,29,0,0,110905146,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105702,188070328,4,0,0,'',0,1,105291,0,0,32,0,0,188070328,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105704,188058282,7,0,0,'',0,1,105291,0,0,34,0,0,188058282,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105705,188070064,1,0,0,'',0,1,105291,0,0,35,0,0,188070064,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105706,188070064,1,0,0,'',0,1,105291,0,0,36,0,0,188070064,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105707,110905146,1,0,0,'',0,0,105291,0,0,37,0,0,110905146,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105710,169610097,1,0,0,'',0,1,105291,0,0,30,0,0,169610097,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(105712,186000469,1,0,0,'',0,0,105291,0,0,0,0,0,186000469,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_cooldowns`
--

DROP TABLE IF EXISTS `item_cooldowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_cooldowns` (
  `player_id` int(11) NOT NULL,
  `delay_id` int(11) NOT NULL,
  `use_delay` int(10) unsigned NOT NULL,
  `reuse_time` bigint(13) NOT NULL,
  PRIMARY KEY (`player_id`,`delay_id`),
  CONSTRAINT `item_cooldowns_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_cooldowns`
--

LOCK TABLES `item_cooldowns` WRITE;
/*!40000 ALTER TABLE `item_cooldowns` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_cooldowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_stones`
--

DROP TABLE IF EXISTS `item_stones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_stones` (
  `item_unique_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `slot` int(2) NOT NULL,
  `category` int(2) NOT NULL DEFAULT 0,
  `polishNumber` int(11) NOT NULL DEFAULT 0,
  `polishCharge` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_unique_id`,`slot`,`category`),
  CONSTRAINT `item_stones_ibfk_1` FOREIGN KEY (`item_unique_id`) REFERENCES `inventory` (`item_unique_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_stones`
--

LOCK TABLES `item_stones` WRITE;
/*!40000 ALTER TABLE `item_stones` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_stones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legion_announcement_list`
--

DROP TABLE IF EXISTS `legion_announcement_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legion_announcement_list` (
  `legion_id` int(11) NOT NULL,
  `announcement` varchar(256) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  KEY `legion_id` (`legion_id`),
  CONSTRAINT `legion_announcement_list_ibfk_1` FOREIGN KEY (`legion_id`) REFERENCES `legions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legion_announcement_list`
--

LOCK TABLES `legion_announcement_list` WRITE;
/*!40000 ALTER TABLE `legion_announcement_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `legion_announcement_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legion_emblems`
--

DROP TABLE IF EXISTS `legion_emblems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legion_emblems` (
  `legion_id` int(11) NOT NULL,
  `emblem_id` int(1) NOT NULL DEFAULT 0,
  `color_r` int(3) NOT NULL DEFAULT 0,
  `color_g` int(3) NOT NULL DEFAULT 0,
  `color_b` int(3) NOT NULL DEFAULT 0,
  `emblem_type` enum('DEFAULT','CUSTOM') NOT NULL DEFAULT 'DEFAULT',
  `emblem_data` longblob DEFAULT NULL,
  PRIMARY KEY (`legion_id`),
  CONSTRAINT `legion_emblems_ibfk_1` FOREIGN KEY (`legion_id`) REFERENCES `legions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legion_emblems`
--

LOCK TABLES `legion_emblems` WRITE;
/*!40000 ALTER TABLE `legion_emblems` DISABLE KEYS */;
/*!40000 ALTER TABLE `legion_emblems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legion_history`
--

DROP TABLE IF EXISTS `legion_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legion_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `legion_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `history_type` enum('CREATE','JOIN','KICK','APPOINTED','EMBLEM_REGISTER','EMBLEM_MODIFIED','ITEM_DEPOSIT','ITEM_WITHDRAW','KINAH_DEPOSIT','KINAH_WITHDRAW','LEVEL_UP') NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `tab_id` smallint(3) NOT NULL DEFAULT 0,
  `description` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `legion_id` (`legion_id`),
  CONSTRAINT `legion_history_ibfk_1` FOREIGN KEY (`legion_id`) REFERENCES `legions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legion_history`
--

LOCK TABLES `legion_history` WRITE;
/*!40000 ALTER TABLE `legion_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `legion_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legion_join_requests`
--

DROP TABLE IF EXISTS `legion_join_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legion_join_requests` (
  `legionId` int(11) NOT NULL DEFAULT 0,
  `playerId` int(11) NOT NULL DEFAULT 0,
  `playerName` varchar(64) NOT NULL DEFAULT '',
  `playerClassId` int(2) NOT NULL DEFAULT 0,
  `playerRaceId` int(2) NOT NULL DEFAULT 0,
  `playerLevel` int(4) NOT NULL DEFAULT 0,
  `playerGenderId` int(2) NOT NULL DEFAULT 0,
  `joinRequestMsg` varchar(40) NOT NULL DEFAULT '',
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`legionId`,`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legion_join_requests`
--

LOCK TABLES `legion_join_requests` WRITE;
/*!40000 ALTER TABLE `legion_join_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `legion_join_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legion_members`
--

DROP TABLE IF EXISTS `legion_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legion_members` (
  `legion_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `nickname` varchar(10) NOT NULL DEFAULT '',
  `rank` enum('BRIGADE_GENERAL','CENTURION','LEGIONARY','DEPUTY','VOLUNTEER') NOT NULL DEFAULT 'VOLUNTEER',
  `selfintro` varchar(32) DEFAULT '',
  `challenge_score` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`),
  KEY `player_id` (`player_id`),
  KEY `legion_id` (`legion_id`),
  CONSTRAINT `legion_members_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `legion_members_ibfk_2` FOREIGN KEY (`legion_id`) REFERENCES `legions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legion_members`
--

LOCK TABLES `legion_members` WRITE;
/*!40000 ALTER TABLE `legion_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `legion_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `legions`
--

DROP TABLE IF EXISTS `legions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legions` (
  `id` int(11) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `level` int(1) NOT NULL DEFAULT 1,
  `contribution_points` bigint(20) NOT NULL DEFAULT 0,
  `deputy_permission` int(11) NOT NULL DEFAULT 7692,
  `centurion_permission` int(11) NOT NULL DEFAULT 7176,
  `legionary_permission` int(11) NOT NULL DEFAULT 6144,
  `volunteer_permission` int(11) NOT NULL DEFAULT 2048,
  `disband_time` int(11) NOT NULL DEFAULT 0,
  `rank_cp` int(11) NOT NULL DEFAULT 0,
  `rank_pos` int(11) NOT NULL DEFAULT 0,
  `old_rank_pos` int(11) NOT NULL DEFAULT 0,
  `world_owner` int(11) NOT NULL DEFAULT 0,
  `description` varchar(255) NOT NULL DEFAULT '',
  `joinType` int(1) NOT NULL DEFAULT 0,
  `minJoinLevel` int(3) NOT NULL DEFAULT 0,
  `territory` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legions`
--

LOCK TABLES `legions` WRITE;
/*!40000 ALTER TABLE `legions` DISABLE KEYS */;
/*!40000 ALTER TABLE `legions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lumiel_transform`
--

DROP TABLE IF EXISTS `lumiel_transform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lumiel_transform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) NOT NULL,
  `lumiel_id` int(11) NOT NULL,
  `points` bigint(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lumiel_transform`
--

LOCK TABLES `lumiel_transform` WRITE;
/*!40000 ALTER TABLE `lumiel_transform` DISABLE KEYS */;
INSERT INTO `lumiel_transform` VALUES (1,105325,11,0),(2,105325,14,0),(3,105325,17,0),(4,105193,11,0),(5,105193,14,0),(6,105193,17,0),(7,105181,11,0),(8,105181,14,0),(9,105181,17,0),(10,105291,11,0),(11,105291,14,0),(12,105291,17,0);
/*!40000 ALTER TABLE `lumiel_transform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail`
--

DROP TABLE IF EXISTS `mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail` (
  `mail_unique_id` int(11) NOT NULL,
  `mail_recipient_id` int(11) NOT NULL,
  `sender_name` varchar(26) NOT NULL,
  `mail_title` varchar(32) NOT NULL,
  `mail_message` varchar(1000) NOT NULL,
  `unread` tinyint(4) NOT NULL DEFAULT 1,
  `attached_item_id` int(11) NOT NULL,
  `attached_kinah_count` bigint(20) NOT NULL,
  `express` tinyint(4) NOT NULL DEFAULT 0,
  `recieved_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`mail_unique_id`),
  KEY `mail_recipient_id` (`mail_recipient_id`),
  CONSTRAINT `FK_mail` FOREIGN KEY (`mail_recipient_id`) REFERENCES `players` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail`
--

LOCK TABLES `mail` WRITE;
/*!40000 ALTER TABLE `mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `network_ban`
--

DROP TABLE IF EXISTS `network_ban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `network_ban` (
  `uniId` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `details` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uniId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `network_ban`
--

LOCK TABLES `network_ban` WRITE;
/*!40000 ALTER TABLE `network_ban` DISABLE KEYS */;
/*!40000 ALTER TABLE `network_ban` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `old_names`
--

DROP TABLE IF EXISTS `old_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `old_names` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `player_id` int(11) NOT NULL,
  `old_name` varchar(50) NOT NULL,
  `new_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `old_names`
--

LOCK TABLES `old_names` WRITE;
/*!40000 ALTER TABLE `old_names` DISABLE KEYS */;
/*!40000 ALTER TABLE `old_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `petitions`
--

DROP TABLE IF EXISTS `petitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `petitions` (
  `id` bigint(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `add_data` varchar(255) DEFAULT NULL,
  `time` bigint(11) NOT NULL DEFAULT 0,
  `status` enum('PENDING','IN_PROGRESS','REPLIED') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `petitions`
--

LOCK TABLES `petitions` WRITE;
/*!40000 ALTER TABLE `petitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `petitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_achievement_actions`
--

DROP TABLE IF EXISTS `player_achievement_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_achievement_actions` (
  `object_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `state` tinyint(1) NOT NULL,
  `step` int(11) NOT NULL DEFAULT 0,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `type` int(11) NOT NULL,
  `achievement_obj` int(11) NOT NULL,
  PRIMARY KEY (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_achievement_actions`
--

LOCK TABLES `player_achievement_actions` WRITE;
/*!40000 ALTER TABLE `player_achievement_actions` DISABLE KEYS */;
INSERT INTO `player_achievement_actions` VALUES (105195,5008,105181,2,1,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105194),(105196,1017,105181,2,10,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105194),(105197,2024,105181,2,30,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105194),(105198,3047,105181,1,0,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105194),(105199,2025,105181,1,2,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105194),(105200,4009,105181,1,6,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105194),(105202,5008,105181,2,1,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105201),(105203,1017,105181,2,10,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105201),(105204,2024,105181,2,30,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105201),(105205,3047,105181,1,0,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105201),(105206,2025,105181,1,2,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105201),(105207,4009,105181,1,6,'2026-07-20 23:22:23','2026-07-22 07:00:00',1,105201),(105304,5008,105291,2,1,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105303),(105305,1017,105291,1,1,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105303),(105306,2024,105291,1,1,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105303),(105307,3047,105291,1,0,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105303),(105308,2025,105291,1,0,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105303),(105309,4009,105291,1,0,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105303),(105311,5008,105291,2,1,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105310),(105312,1017,105291,2,10,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105310),(105313,2024,105291,1,13,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105310),(105314,3047,105291,1,0,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105310),(105315,2025,105291,1,1,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105310),(105316,4009,105291,1,2,'2026-07-29 20:41:10','2026-07-30 07:00:00',1,105310),(105318,3040,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105321,3051,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105322,2041,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105323,3052,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105324,3041,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105325,3039,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105326,2027,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105327,2046,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105328,2047,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105329,3033,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105330,6007,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105331,3042,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105332,3043,105291,1,0,'2026-07-30 22:00:42','2026-08-07 07:00:00',2,105302),(105506,3040,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105507,3051,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105508,2041,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105509,3052,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105510,3041,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105511,3039,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105512,2027,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105513,2046,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105514,2047,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105515,3033,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105516,6007,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105517,3042,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505),(105518,3043,105181,1,0,'2026-07-29 15:38:46','2026-08-05 07:00:00',2,105505);
/*!40000 ALTER TABLE `player_achievement_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_achievements`
--

DROP TABLE IF EXISTS `player_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_achievements` (
  `object_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `state` tinyint(1) NOT NULL,
  `step` int(11) NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_achievements`
--

LOCK TABLES `player_achievements` WRITE;
/*!40000 ALTER TABLE `player_achievements` DISABLE KEYS */;
INSERT INTO `player_achievements` VALUES (105194,36,105181,1,3,1,'2026-07-20 23:22:23','2026-07-22 07:00:00'),(105201,36,105181,1,3,1,'2026-07-20 23:22:23','2026-07-22 07:00:00'),(105302,58,105291,1,0,2,'2026-07-30 22:00:42','2026-08-07 07:00:00'),(105303,37,105291,1,1,1,'2026-07-29 20:41:10','2026-07-30 07:00:00'),(105310,37,105291,1,2,1,'2026-07-29 20:41:10','2026-07-30 07:00:00'),(105505,58,105181,1,0,2,'2026-07-29 15:38:46','2026-08-05 07:00:00');
/*!40000 ALTER TABLE `player_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_appearance`
--

DROP TABLE IF EXISTS `player_appearance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_appearance` (
  `player_id` int(11) NOT NULL,
  `voice` int(11) NOT NULL,
  `skin_rgb` int(11) NOT NULL,
  `hair_rgb` int(11) NOT NULL,
  `eye_rgb` int(11) NOT NULL,
  `lip_rgb` int(11) NOT NULL,
  `face` int(11) NOT NULL,
  `hair` int(11) NOT NULL,
  `deco` int(11) NOT NULL,
  `tattoo` int(11) NOT NULL,
  `face_contour` int(11) NOT NULL,
  `expression` int(11) NOT NULL,
  `pupil_shape` int(11) NOT NULL,
  `remove_mane` int(11) NOT NULL,
  `right_eye_rgb` int(11) NOT NULL,
  `eye_lash_shape` int(11) NOT NULL,
  `jaw_line` int(11) NOT NULL,
  `forehead` int(11) NOT NULL,
  `eye_height` int(11) NOT NULL,
  `eye_space` int(11) NOT NULL,
  `eye_width` int(11) NOT NULL,
  `eye_size` int(11) NOT NULL,
  `eye_shape` int(11) NOT NULL,
  `eye_angle` int(11) NOT NULL,
  `brow_height` int(11) NOT NULL,
  `brow_angle` int(11) NOT NULL,
  `brow_shape` int(11) NOT NULL,
  `nose` int(11) NOT NULL,
  `nose_bridge` int(11) NOT NULL,
  `nose_width` int(11) NOT NULL,
  `nose_tip` int(11) NOT NULL,
  `cheek` int(11) NOT NULL,
  `lip_height` int(11) NOT NULL,
  `mouth_size` int(11) NOT NULL,
  `lip_size` int(11) NOT NULL,
  `smile` int(11) NOT NULL,
  `lip_shape` int(11) NOT NULL,
  `jaw_height` int(11) NOT NULL,
  `chin_jut` int(11) NOT NULL,
  `ear_shape` int(11) NOT NULL,
  `head_size` int(11) NOT NULL,
  `neck` int(11) NOT NULL,
  `neck_length` int(11) NOT NULL,
  `shoulder_size` int(11) NOT NULL,
  `torso` int(11) NOT NULL,
  `chest` int(11) NOT NULL,
  `waist` int(11) NOT NULL,
  `hips` int(11) NOT NULL,
  `arm_thickness` int(11) NOT NULL,
  `hand_size` int(11) NOT NULL,
  `leg_thickness` int(11) NOT NULL,
  `facial_rate` int(11) NOT NULL,
  `foot_size` int(11) NOT NULL,
  `arm_length` int(11) NOT NULL,
  `leg_length` int(11) NOT NULL,
  `shoulders` int(11) NOT NULL,
  `face_shape` int(11) NOT NULL,
  `pupil_size` int(11) NOT NULL,
  `upper_torso` int(11) NOT NULL,
  `fore_arm_thickness` int(11) NOT NULL,
  `hand_span` int(11) NOT NULL,
  `calf_thickness` int(11) NOT NULL,
  `height` float NOT NULL,
  PRIMARY KEY (`player_id`),
  CONSTRAINT `player_id_fk` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_appearance`
--

LOCK TABLES `player_appearance` WRITE;
/*!40000 ALTER TABLE `player_appearance` DISABLE KEYS */;
INSERT INTO `player_appearance` VALUES (105181,0,4407868,16777215,1316095,3223860,42,76,0,0,5,0,23,1,1316095,2,148,0,186,0,155,6,155,10,32,25,194,28,4,20,0,2,186,137,159,38,129,4,129,0,248,5,253,37,249,16,250,12,2,248,253,0,241,249,0,0,190,17,0,0,0,252,1.0445),(105291,0,16046034,7361119,15198207,16770533,0,0,0,0,0,0,19,1,15198207,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,0,200,225,0,0,0,224,0,0,0,242,254,0,247,0,0,0,222,0,249,1.0019);
/*!40000 ALTER TABLE `player_appearance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_bind_point`
--

DROP TABLE IF EXISTS `player_bind_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_bind_point` (
  `player_id` int(11) NOT NULL,
  `map_id` int(11) NOT NULL,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `heading` int(3) NOT NULL,
  PRIMARY KEY (`player_id`),
  CONSTRAINT `player_bind_point_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_bind_point`
--

LOCK TABLES `player_bind_point` WRITE;
/*!40000 ALTER TABLE `player_bind_point` DISABLE KEYS */;
INSERT INTO `player_bind_point` VALUES (105181,220070000,1763.82,2909.7,554.798,100),(105291,120010000,1605.06,1395.07,193.128,68);
/*!40000 ALTER TABLE `player_bind_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_collection_infos`
--

DROP TABLE IF EXISTS `player_collection_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_collection_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) NOT NULL,
  `type` enum('COMMON','ANCIENT','RELIC','EVENT') NOT NULL,
  `level` int(10) NOT NULL DEFAULT 1,
  `exp` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_collection_infos`
--

LOCK TABLES `player_collection_infos` WRITE;
/*!40000 ALTER TABLE `player_collection_infos` DISABLE KEYS */;
INSERT INTO `player_collection_infos` VALUES (9,105181,'RELIC',1,0),(10,105181,'ANCIENT',1,0),(11,105181,'EVENT',1,0),(12,105181,'COMMON',1,0),(13,105291,'COMMON',1,0),(14,105291,'ANCIENT',1,0),(15,105291,'RELIC',1,0),(16,105291,'EVENT',1,0);
/*!40000 ALTER TABLE `player_collection_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_collections`
--

DROP TABLE IF EXISTS `player_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL,
  `complete` tinyint(1) NOT NULL DEFAULT 0,
  `step` int(10) NOT NULL DEFAULT 0,
  `item1` tinyint(1) NOT NULL DEFAULT 0,
  `item2` tinyint(1) NOT NULL DEFAULT 0,
  `item3` tinyint(1) NOT NULL DEFAULT 0,
  `item4` tinyint(1) NOT NULL DEFAULT 0,
  `item5` tinyint(1) NOT NULL DEFAULT 0,
  `item6` tinyint(1) NOT NULL DEFAULT 0,
  `item7` tinyint(1) NOT NULL DEFAULT 0,
  `item8` tinyint(1) NOT NULL DEFAULT 0,
  `item9` tinyint(1) NOT NULL DEFAULT 0,
  `item10` tinyint(1) NOT NULL DEFAULT 0,
  `item11` tinyint(1) NOT NULL DEFAULT 0,
  `item12` tinyint(1) NOT NULL DEFAULT 0,
  `item13` tinyint(1) NOT NULL DEFAULT 0,
  `item14` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_collections`
--

LOCK TABLES `player_collections` WRITE;
/*!40000 ALTER TABLE `player_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_cooldowns`
--

DROP TABLE IF EXISTS `player_cooldowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_cooldowns` (
  `player_id` int(11) NOT NULL,
  `cooldown_id` int(6) NOT NULL,
  `reuse_delay` bigint(13) NOT NULL,
  PRIMARY KEY (`player_id`,`cooldown_id`),
  CONSTRAINT `player_cooldowns_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_cooldowns`
--

LOCK TABLES `player_cooldowns` WRITE;
/*!40000 ALTER TABLE `player_cooldowns` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_cooldowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_cp`
--

DROP TABLE IF EXISTS `player_cp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_cp` (
  `player_id` int(11) NOT NULL,
  `slot` int(11) NOT NULL,
  `point` int(3) NOT NULL,
  PRIMARY KEY (`player_id`,`slot`),
  CONSTRAINT `player_cp_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_cp`
--

LOCK TABLES `player_cp` WRITE;
/*!40000 ALTER TABLE `player_cp` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_cp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_cubic`
--

DROP TABLE IF EXISTS `player_cubic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_cubic` (
  `player_id` int(11) NOT NULL,
  `cubic_id` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `stat_value` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  PRIMARY KEY (`player_id`,`cubic_id`) USING BTREE,
  CONSTRAINT `fk_player_cubic` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_cubic`
--

LOCK TABLES `player_cubic` WRITE;
/*!40000 ALTER TABLE `player_cubic` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_cubic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_effects`
--

DROP TABLE IF EXISTS `player_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_effects` (
  `player_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `skill_lvl` tinyint(4) NOT NULL,
  `current_time` int(11) NOT NULL,
  `end_time` bigint(13) NOT NULL,
  PRIMARY KEY (`player_id`,`skill_id`),
  CONSTRAINT `player_effects_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_effects`
--

LOCK TABLES `player_effects` WRITE;
/*!40000 ALTER TABLE `player_effects` DISABLE KEYS */;
INSERT INTO `player_effects` VALUES (105181,10465,3,777708,1786646301622);
/*!40000 ALTER TABLE `player_effects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_emotions`
--

DROP TABLE IF EXISTS `player_emotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_emotions` (
  `player_id` int(11) NOT NULL,
  `emotion` int(11) NOT NULL,
  `remaining` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`,`emotion`),
  CONSTRAINT `player_emotions_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_emotions`
--

LOCK TABLES `player_emotions` WRITE;
/*!40000 ALTER TABLE `player_emotions` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_emotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_equipment_setting`
--

DROP TABLE IF EXISTS `player_equipment_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_equipment_setting` (
  `player_id` int(11) NOT NULL,
  `slot` int(255) NOT NULL,
  `display` tinyint(2) NOT NULL DEFAULT 0,
  `m_hand` int(21) NOT NULL DEFAULT 0,
  `s_hand` int(21) NOT NULL DEFAULT 0,
  `helmet` int(21) NOT NULL DEFAULT 0,
  `torso` int(21) NOT NULL DEFAULT 0,
  `glove` int(21) NOT NULL DEFAULT 0,
  `boots` int(21) NOT NULL DEFAULT 0,
  `earrings_left` int(21) NOT NULL DEFAULT 0,
  `earrings_right` int(21) NOT NULL DEFAULT 0,
  `ring_left` int(21) NOT NULL DEFAULT 0,
  `ring_right` int(21) NOT NULL DEFAULT 0,
  `necklace` int(21) NOT NULL DEFAULT 0,
  `shoulder` int(21) NOT NULL DEFAULT 0,
  `pants` int(21) NOT NULL DEFAULT 0,
  `powershard_left` int(21) NOT NULL DEFAULT 0,
  `powershard_right` int(21) NOT NULL DEFAULT 0,
  `wings` int(21) NOT NULL DEFAULT 0,
  `waist` int(21) NOT NULL DEFAULT 0,
  `m_off_hand` int(21) NOT NULL DEFAULT 0,
  `s_off_hand` int(21) NOT NULL DEFAULT 0,
  `plume` int(21) NOT NULL DEFAULT 0,
  `bracelet` int(21) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`,`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_equipment_setting`
--

LOCK TABLES `player_equipment_setting` WRITE;
/*!40000 ALTER TABLE `player_equipment_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_equipment_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_events_window`
--

DROP TABLE IF EXISTS `player_events_window`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_events_window` (
  `account_id` int(11) NOT NULL DEFAULT 0,
  `event_id` int(11) NOT NULL DEFAULT 0,
  `last_stamp` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `elapsed` int(11) NOT NULL DEFAULT 0,
  `reward_recived_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`account_id`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_events_window`
--

LOCK TABLES `player_events_window` WRITE;
/*!40000 ALTER TABLE `player_events_window` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_events_window` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_fame`
--

DROP TABLE IF EXISTS `player_fame`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_fame` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) NOT NULL,
  `fame_id` int(10) NOT NULL,
  `level` int(10) NOT NULL DEFAULT 1,
  `exp` bigint(30) NOT NULL DEFAULT 0,
  `exp_loss` bigint(30) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_fame`
--

LOCK TABLES `player_fame` WRITE;
/*!40000 ALTER TABLE `player_fame` DISABLE KEYS */;
INSERT INTO `player_fame` VALUES (51,105181,1,1,0,0),(52,105181,2,1,380,0),(53,105181,3,1,0,0),(54,105181,4,1,0,0),(55,105181,5,1,0,0),(56,105181,6,1,0,0),(57,105181,7,1,0,0),(58,105291,1,1,0,0),(59,105291,2,1,0,0),(60,105291,3,1,0,0),(61,105291,4,1,0,0),(62,105291,5,1,0,0),(63,105291,6,1,0,0),(64,105291,7,1,0,0);
/*!40000 ALTER TABLE `player_fame` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_game_stats`
--

DROP TABLE IF EXISTS `player_game_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_game_stats` (
  `player_id` int(11) NOT NULL,
  `defense_physic` int(11) NOT NULL DEFAULT 1,
  `block` int(11) NOT NULL DEFAULT 1,
  `parry` int(11) NOT NULL DEFAULT 1,
  `magical_critical` int(11) NOT NULL DEFAULT 1,
  `evasion` int(11) NOT NULL DEFAULT 1,
  `precision` int(11) NOT NULL DEFAULT 1,
  `attack` int(11) NOT NULL DEFAULT 1,
  `magical_precision` int(11) NOT NULL DEFAULT 1,
  `attack_speed` int(11) NOT NULL DEFAULT 1,
  `magical_resist` int(11) NOT NULL DEFAULT 1,
  `magical_attack` int(11) NOT NULL DEFAULT 1,
  `main_hand_magical_attack` int(11) NOT NULL DEFAULT 1,
  `off_hand_magical_attack` int(11) NOT NULL DEFAULT 1,
  `physical_critical` int(11) NOT NULL DEFAULT 1,
  `attack_range` int(11) NOT NULL DEFAULT 1,
  `magical_defense` int(11) NOT NULL DEFAULT 1,
  `agility` int(11) NOT NULL DEFAULT 1,
  `knowledge` int(11) NOT NULL DEFAULT 1,
  `will` int(11) NOT NULL DEFAULT 1,
  `magical_boost` int(11) NOT NULL DEFAULT 1,
  `magical_boost_resist` int(11) NOT NULL DEFAULT 1,
  `physical_critical_resist` int(11) NOT NULL DEFAULT 1,
  `magical_critical_resist` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`player_id`),
  CONSTRAINT `player_game_stats` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_game_stats`
--

LOCK TABLES `player_game_stats` WRITE;
/*!40000 ALTER TABLE `player_game_stats` DISABLE KEYS */;
INSERT INTO `player_game_stats` VALUES (105181,139,1048,1263,50,1048,110,100,1351,2000,0,0,0,0,0,15000,446,100,110,110,0,0,90,50),(105291,871,1081,3445,50,1029,90,105,1151,1500,0,0,0,0,0,1500,574,90,105,120,0,140,90,130);
/*!40000 ALTER TABLE `player_game_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_life_stats`
--

DROP TABLE IF EXISTS `player_life_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_life_stats` (
  `player_id` int(11) NOT NULL,
  `hp` int(11) NOT NULL DEFAULT 1,
  `mp` int(11) NOT NULL DEFAULT 1,
  `fp` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`player_id`),
  CONSTRAINT `FK_player_life_stats` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_life_stats`
--

LOCK TABLES `player_life_stats` WRITE;
/*!40000 ALTER TABLE `player_life_stats` DISABLE KEYS */;
INSERT INTO `player_life_stats` VALUES (105181,9107,7598,120),(105291,12258,9990,120);
/*!40000 ALTER TABLE `player_life_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_luna_shop`
--

DROP TABLE IF EXISTS `player_luna_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_luna_shop` (
  `player_id` int(10) NOT NULL,
  `free_under` tinyint(1) NOT NULL,
  `free_munition` tinyint(1) NOT NULL,
  `free_chest` tinyint(1) NOT NULL,
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_luna_shop`
--

LOCK TABLES `player_luna_shop` WRITE;
/*!40000 ALTER TABLE `player_luna_shop` DISABLE KEYS */;
INSERT INTO `player_luna_shop` VALUES (105181,1,1,0),(105291,1,1,1);
/*!40000 ALTER TABLE `player_luna_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_macrosses`
--

DROP TABLE IF EXISTS `player_macrosses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_macrosses` (
  `player_id` int(11) NOT NULL,
  `order` int(3) NOT NULL,
  `macro` text NOT NULL,
  UNIQUE KEY `main` (`player_id`,`order`),
  CONSTRAINT `player_macrosses_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_macrosses`
--

LOCK TABLES `player_macrosses` WRITE;
/*!40000 ALTER TABLE `player_macrosses` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_macrosses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_minions`
--

DROP TABLE IF EXISTS `player_minions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_minions` (
  `player_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL AUTO_INCREMENT,
  `minion_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `grade` varchar(11) NOT NULL,
  `level` varchar(11) NOT NULL,
  `birthday` timestamp NOT NULL DEFAULT current_timestamp(),
  `growth_points` int(11) NOT NULL DEFAULT 0,
  `is_lock` bigint(1) NOT NULL DEFAULT 1,
  `despawn_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=105717 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_minions`
--

LOCK TABLES `player_minions` WRITE;
/*!40000 ALTER TABLE `player_minions` DISABLE KEYS */;
INSERT INTO `player_minions` VALUES (105181,105529,981154,'Kromede of Battle','S','1','2026-07-29 16:19:38',0,0,'2026-07-29 16:19:38'),(105181,105531,981154,'Kromede of Battle','S','1','2026-07-29 16:19:49',136023168,0,'2026-07-29 16:19:49'),(105291,105715,980070,'Sita','A','1','2026-08-13 16:30:04',0,0,'2026-08-13 16:30:04'),(105291,105716,980060,'Grendal','A','1','2026-08-13 16:30:11',0,0,'2026-08-13 16:30:11');
/*!40000 ALTER TABLE `player_minions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_monsterbook`
--

DROP TABLE IF EXISTS `player_monsterbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_monsterbook` (
  `player_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `kill_count` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `claim_reward` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`,`id`),
  CONSTRAINT `fk_player_monsterbook` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_monsterbook`
--

LOCK TABLES `player_monsterbook` WRITE;
/*!40000 ALTER TABLE `player_monsterbook` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_monsterbook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_motions`
--

DROP TABLE IF EXISTS `player_motions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_motions` (
  `player_id` int(11) NOT NULL,
  `motion_id` int(3) NOT NULL,
  `time` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`,`motion_id`) USING BTREE,
  CONSTRAINT `motions_player_id_fk` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_motions`
--

LOCK TABLES `player_motions` WRITE;
/*!40000 ALTER TABLE `player_motions` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_motions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_npc_factions`
--

DROP TABLE IF EXISTS `player_npc_factions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_npc_factions` (
  `player_id` int(11) NOT NULL,
  `faction_id` int(2) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `time` int(11) NOT NULL,
  `state` enum('NOTING','START','COMPLETE') NOT NULL DEFAULT 'NOTING',
  `quest_id` int(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`,`faction_id`),
  CONSTRAINT `player_npc_factions_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_npc_factions`
--

LOCK TABLES `player_npc_factions` WRITE;
/*!40000 ALTER TABLE `player_npc_factions` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_npc_factions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_passkey`
--

DROP TABLE IF EXISTS `player_passkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_passkey` (
  `account_id` int(11) NOT NULL,
  `passkey` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`account_id`,`passkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_passkey`
--

LOCK TABLES `player_passkey` WRITE;
/*!40000 ALTER TABLE `player_passkey` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_passkey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_pets`
--

DROP TABLE IF EXISTS `player_pets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_pets` (
  `player_id` int(11) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `decoration` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `hungry_level` tinyint(4) NOT NULL DEFAULT 0,
  `feed_progress` int(11) NOT NULL DEFAULT 0,
  `reuse_time` bigint(20) NOT NULL DEFAULT 0,
  `birthday` timestamp NOT NULL DEFAULT current_timestamp(),
  `mood_started` bigint(20) NOT NULL DEFAULT 0,
  `counter` int(11) NOT NULL DEFAULT 0,
  `mood_cd_started` bigint(20) NOT NULL DEFAULT 0,
  `gift_cd_started` bigint(20) NOT NULL DEFAULT 0,
  `dopings` varchar(80) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `despawn_time` timestamp NULL DEFAULT NULL,
  `expire_time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`,`pet_id`),
  CONSTRAINT `FK_player_pets` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_pets`
--

LOCK TABLES `player_pets` WRITE;
/*!40000 ALTER TABLE `player_pets` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_pets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_punishments`
--

DROP TABLE IF EXISTS `player_punishments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_punishments` (
  `player_id` int(11) NOT NULL,
  `punishment_type` enum('PRISON','GATHER','CHARBAN') NOT NULL,
  `start_time` int(10) unsigned DEFAULT 0,
  `duration` int(10) unsigned DEFAULT 0,
  `reason` text DEFAULT NULL,
  PRIMARY KEY (`player_id`,`punishment_type`),
  CONSTRAINT `player_punishments_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_punishments`
--

LOCK TABLES `player_punishments` WRITE;
/*!40000 ALTER TABLE `player_punishments` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_punishments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_quests`
--

DROP TABLE IF EXISTS `player_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_quests` (
  `player_id` int(11) NOT NULL,
  `quest_id` int(10) unsigned NOT NULL DEFAULT 0,
  `status` varchar(10) NOT NULL DEFAULT 'NONE',
  `quest_vars` int(10) unsigned NOT NULL DEFAULT 0,
  `complete_count` int(3) unsigned NOT NULL DEFAULT 0,
  `next_repeat_time` timestamp NULL DEFAULT NULL,
  `reward` smallint(3) DEFAULT NULL,
  `complete_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`player_id`,`quest_id`),
  CONSTRAINT `player_quests_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_quests`
--

LOCK TABLES `player_quests` WRITE;
/*!40000 ALTER TABLE `player_quests` DISABLE KEYS */;
INSERT INTO `player_quests` VALUES (105181,2000,'COMPLETE',0,1,NULL,0,'2026-07-21 21:33:33'),(105181,2008,'COMPLETE',0,1,NULL,0,'2026-07-29 15:47:23'),(105181,24043,'LOCKED',0,0,NULL,0,NULL),(105181,70000,'COMPLETE',0,1,NULL,0,'2026-07-21 21:35:07'),(105181,70001,'COMPLETE',0,1,NULL,0,'2026-07-21 21:35:39'),(105181,70003,'COMPLETE',0,1,NULL,0,'2026-07-21 21:48:19'),(105181,70004,'COMPLETE',0,1,NULL,0,'2026-07-23 13:18:15'),(105181,70005,'COMPLETE',0,1,NULL,0,'2026-07-23 14:52:04'),(105181,70006,'COMPLETE',0,1,NULL,0,'2026-07-26 16:06:13'),(105181,70007,'COMPLETE',0,1,NULL,0,'2026-07-26 16:15:09'),(105181,70008,'COMPLETE',0,1,NULL,0,'2026-07-26 16:16:43'),(105181,70009,'COMPLETE',0,1,NULL,0,'2026-07-29 15:45:27'),(105181,70100,'COMPLETE',0,1,NULL,0,'2026-07-30 12:53:29'),(105181,70101,'COMPLETE',0,1,NULL,0,'2026-07-30 12:54:29'),(105181,70110,'LOCKED',0,0,NULL,0,NULL),(105181,70201,'LOCKED',0,0,NULL,0,NULL),(105181,70202,'LOCKED',0,0,NULL,0,NULL),(105181,70203,'LOCKED',0,0,NULL,0,NULL),(105181,70204,'LOCKED',0,0,NULL,0,NULL),(105181,70205,'LOCKED',0,0,NULL,0,NULL),(105181,70206,'LOCKED',0,0,NULL,0,NULL),(105181,70207,'LOCKED',0,0,NULL,0,NULL),(105181,70208,'LOCKED',0,0,NULL,0,NULL),(105181,70300,'LOCKED',0,0,NULL,0,NULL),(105181,70301,'LOCKED',0,0,NULL,0,NULL),(105181,70302,'LOCKED',0,0,NULL,0,NULL),(105181,70303,'LOCKED',0,0,NULL,0,NULL),(105181,70304,'LOCKED',0,0,NULL,0,NULL),(105181,70305,'LOCKED',0,0,NULL,0,NULL),(105181,70306,'LOCKED',0,0,NULL,0,NULL),(105181,70307,'LOCKED',0,0,NULL,0,NULL),(105181,70308,'LOCKED',0,0,NULL,0,NULL),(105181,70309,'LOCKED',0,0,NULL,0,NULL),(105181,70500,'LOCKED',0,0,NULL,0,NULL),(105181,70501,'LOCKED',0,0,NULL,0,NULL),(105181,70502,'LOCKED',0,0,NULL,0,NULL),(105181,70503,'LOCKED',0,0,NULL,0,NULL),(105181,70504,'LOCKED',0,0,NULL,0,NULL),(105181,70505,'LOCKED',0,0,NULL,0,NULL),(105181,71101,'COMPLETE',0,1,NULL,0,'2026-07-27 22:11:13'),(105181,71102,'COMPLETE',0,1,NULL,0,'2026-07-27 23:04:54'),(105181,71103,'COMPLETE',0,1,NULL,0,'2026-07-29 15:44:34'),(105181,71601,'LOCKED',0,0,NULL,0,NULL),(105181,71603,'LOCKED',0,0,NULL,0,NULL),(105181,90002,'START',0,0,NULL,0,NULL),(105291,2000,'COMPLETE',0,1,NULL,0,'2026-07-29 21:12:49'),(105291,2008,'COMPLETE',0,1,NULL,0,'2026-07-29 21:34:36'),(105291,24043,'LOCKED',0,0,NULL,0,NULL),(105291,70000,'COMPLETE',0,1,NULL,0,'2026-07-29 21:13:50'),(105291,70001,'COMPLETE',0,1,NULL,0,'2026-07-29 21:14:27'),(105291,70003,'COMPLETE',0,1,NULL,0,'2026-07-29 21:15:16'),(105291,70004,'COMPLETE',0,1,NULL,0,'2026-07-29 21:15:25'),(105291,70005,'COMPLETE',0,1,NULL,0,'2026-07-29 21:19:48'),(105291,70006,'COMPLETE',0,1,NULL,0,'2026-07-29 21:21:53'),(105291,70007,'COMPLETE',0,1,NULL,0,'2026-07-29 21:25:12'),(105291,70008,'COMPLETE',0,1,NULL,0,'2026-07-29 21:26:43'),(105291,70009,'COMPLETE',0,1,NULL,0,'2026-07-29 21:32:25'),(105291,70100,'COMPLETE',0,1,NULL,0,'2026-07-30 12:16:46'),(105291,70101,'START',0,0,NULL,0,NULL),(105291,70110,'LOCKED',0,0,NULL,0,NULL),(105291,70201,'LOCKED',0,0,NULL,0,NULL),(105291,70202,'LOCKED',0,0,NULL,0,NULL),(105291,70203,'LOCKED',0,0,NULL,0,NULL),(105291,70204,'LOCKED',0,0,NULL,0,NULL),(105291,70205,'LOCKED',0,0,NULL,0,NULL),(105291,70206,'LOCKED',0,0,NULL,0,NULL),(105291,70207,'LOCKED',0,0,NULL,0,NULL),(105291,70208,'LOCKED',0,0,NULL,0,NULL),(105291,70300,'LOCKED',0,0,NULL,0,NULL),(105291,70301,'LOCKED',0,0,NULL,0,NULL),(105291,70302,'LOCKED',0,0,NULL,0,NULL),(105291,70303,'LOCKED',0,0,NULL,0,NULL),(105291,70304,'LOCKED',0,0,NULL,0,NULL),(105291,70305,'LOCKED',0,0,NULL,0,NULL),(105291,70306,'LOCKED',0,0,NULL,0,NULL),(105291,70307,'LOCKED',0,0,NULL,0,NULL),(105291,70308,'LOCKED',0,0,NULL,0,NULL),(105291,70309,'LOCKED',0,0,NULL,0,NULL),(105291,70500,'LOCKED',0,0,NULL,0,NULL),(105291,70501,'LOCKED',0,0,NULL,0,NULL),(105291,70502,'LOCKED',0,0,NULL,0,NULL),(105291,70503,'LOCKED',0,0,NULL,0,NULL),(105291,70504,'LOCKED',0,0,NULL,0,NULL),(105291,70505,'LOCKED',0,0,NULL,0,NULL),(105291,71101,'COMPLETE',0,1,NULL,0,'2026-07-29 21:29:01'),(105291,71102,'COMPLETE',0,1,NULL,0,'2026-07-29 21:30:22'),(105291,71103,'NONE',0,0,NULL,0,NULL),(105291,71601,'LOCKED',0,0,NULL,0,NULL),(105291,71603,'LOCKED',0,0,NULL,0,NULL),(105291,90002,'COMPLETE',0,1,NULL,0,'2026-07-29 21:39:15');
/*!40000 ALTER TABLE `player_quests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_ranking`
--

DROP TABLE IF EXISTS `player_ranking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking` (
  `player_id` int(10) NOT NULL,
  `table_id` int(10) NOT NULL,
  `rank` int(10) NOT NULL DEFAULT 0,
  `last_rank` int(10) NOT NULL DEFAULT 0,
  `points` int(10) NOT NULL DEFAULT 0,
  `last_points` int(10) NOT NULL DEFAULT 0,
  `high_points` int(10) NOT NULL DEFAULT 0,
  `low_points` int(10) NOT NULL DEFAULT 0,
  `position_match` int(10) NOT NULL DEFAULT 5,
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_ranking`
--

LOCK TABLES `player_ranking` WRITE;
/*!40000 ALTER TABLE `player_ranking` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_ranking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_recipes`
--

DROP TABLE IF EXISTS `player_recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_recipes` (
  `player_id` int(11) NOT NULL,
  `recipe_id` int(11) NOT NULL,
  PRIMARY KEY (`player_id`,`recipe_id`),
  CONSTRAINT `player_recipes_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_recipes`
--

LOCK TABLES `player_recipes` WRITE;
/*!40000 ALTER TABLE `player_recipes` DISABLE KEYS */;
INSERT INTO `player_recipes` VALUES (105181,155005001),(105181,155005002),(105181,155005005),(105291,155005001),(105291,155005002),(105291,155005005);
/*!40000 ALTER TABLE `player_recipes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_registered_items`
--

DROP TABLE IF EXISTS `player_registered_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_registered_items` (
  `player_id` int(10) NOT NULL,
  `item_unique_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `expire_time` int(20) DEFAULT NULL,
  `color` int(11) DEFAULT NULL,
  `color_expires` int(11) NOT NULL DEFAULT 0,
  `owner_use_count` int(10) NOT NULL DEFAULT 0,
  `visitor_use_count` int(10) NOT NULL DEFAULT 0,
  `x` float NOT NULL DEFAULT 0,
  `y` float NOT NULL DEFAULT 0,
  `z` float NOT NULL DEFAULT 0,
  `h` smallint(3) DEFAULT NULL,
  `area` enum('NONE','INTERIOR','EXTERIOR','ALL','DECOR') NOT NULL DEFAULT 'NONE',
  `floor` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`,`item_unique_id`,`item_id`),
  CONSTRAINT `player_regitems_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_registered_items`
--

LOCK TABLES `player_registered_items` WRITE;
/*!40000 ALTER TABLE `player_registered_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_registered_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_settings`
--

DROP TABLE IF EXISTS `player_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_settings` (
  `player_id` int(11) NOT NULL,
  `settings_type` tinyint(1) NOT NULL,
  `settings` blob NOT NULL,
  PRIMARY KEY (`player_id`,`settings_type`),
  CONSTRAINT `ps_pl_fk` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_settings`
--

LOCK TABLES `player_settings` WRITE;
/*!40000 ALTER TABLE `player_settings` DISABLE KEYS */;
INSERT INTO `player_settings` VALUES (105181,-2,'0'),(105181,-1,'0'),(105181,0,'�\0\0�p\0\0x��]�r#�����?t�}�ڗ�qO̴Z��h��H-!��%�5�����^�\0J=��Ū��@\"�Hl���?�����7q�I|{�,^Ľx\'�w��_E%�?�\'\'q-���ӓ�������G�\Z䯟�g��g��(��Y��ػ[q%����7�ٳ�l�M���4��Vl�����[q\Z#�U>W�_�ݽ�V�_�<�;O��~e�y�\0h����\\�^j�{�/9��+i�?,\')6.O��$�Am�=�Z<�{�`3�X������+�V����M>ق-�y��Q�y9�I\'y��en^-�B�k��F��J]n��)��u;������I�l�*�w��{�;�\\�..���%r��=��J]�e>C�o$ۓD�N>�&������T���UU�w�y勐�]�]{y-C�s7�s7��[��UܝD����*�^��b�~� �c1���{�詘{\\�=I�\\�=�➡�T��s�~�����1§~��D���k��g�����E~.�u#k���7�wOշ]��_d�/�^gy�U~_��Y��*�j�Q�_����y�E��S�r�E���r�ף,ü��d�/��K�ҿ���\\_������y�#���>�^*Yc_ly����k�8��t���ke�����E���(��iM����T��W���I�����/��?׆����3D����zY%z\n�gĞ���9���4��\ZZO�1�}iT�z̲��-�꼨2��s�E\\qJ��\"����Q���Q�L��(�B�l�o�:���ۤ>K^V��5�EuR��}���m!�KP����q�%Q%��e�V�&-�1�嵺l��lA��Z�փ�JW�,ϕ���N��s�ӡ�\\9�t(��d�ʵ�$���o�L͢�q�2텴�-p�ڱ#ϔ��$e}�R�2�z���Y�C�I9��q�+��Rr8�p�.)\'��ًC�����!�ss��c�7m�LC\n�fj\n�8{p�����q��\0�Ls��\\\\�:�P��ՠ��z�{G�A��y�<��;�sȣ˹�Uܜ��v7gS4�[�����Wqs6G��Uܱ\r��L�N[��_���\'��K�J��B���8\\S���k�b��pq����K\nW��0)��3�{=��A�YC4�1��u�H�R��=�\n��yu��޸ɧ���:�j�*J��4�����:GZq�&�1�X���b��L�Gh�[�9\\	Qci���Kc�q\'�X֭���^�[����!Ƙg��[�k~j����A�G��Ci;���x*:���C3�hR�R�\Z���MH+I�ۋo`=�,F�{��u�uXER?�����T=��m`�6�e���T1�����:p�5�9[��#�%>d��qΕ�㐿�ha����S��^%b��b�Q����|jJ�Y�t��fj𙔄2�G}����y�\\ìC��̩tK	���̼�/����������%�*���;�>\'��ޯ�v�e�u�k����)L̂���{�yi�s�|1:d{ԫ´G���iѓ���������i��g&�~T�2���A̪/�jB�]�Ac$)�:��k�{Xk^�\n�y;�4}$)�2�����SC˯�C�~����^z.��|F\n�1|�l�mTo�*f��(�<B�}��8��BD7F>7�2�b\"ee���}���K)�`ig�+v�\'.��)c)�����^��w�<D%���.IJz�\"\0�y���P���)|���.n�3pMz�a\r�+�_�q���!�ʳ� ����4�p��H�U�*����xe�a�smUųG�m���J���S���Oڋ���KN��\Z�M��z������JnVHN�\n�]��v���<���J�VHN�\"�C��~�����<JVH�$O��GO��b~����N8��a\r�oz��.��f\\��Q���¯�K��è�p{H}��\Z<b���ȫr�M��<܋�s7���+\n9�a��Y�=��p�nQve8�o~��\0S�f���]r��r2�h��]E�u�KУ����H�J�7bo\n������݇ػ$�[Ӹ�x�V��|4�n�]^ٱ.Z�YGb�-�P�ˍ��L.�����9u���Ls��Z���ʭڡ����4�����I�x/�r!����{��u��i�&���a��Kk��%~��p�wힵ�GQ&�F?U�v��\\��XYN��u�t��E^]��O`��`�h%�[&?/~�}�ҚY(��Xˤ�cFJzS �)���)�m���Pz:v��wһB������H���cHJ�P }(���#)�c���P��Z�T }JJ7}��;��T)��02�4�ΌVve$�F��NX<F9��|�Q���9����^�\Zj	�q����߀k���=���#\\���\0gf	������[K\\_��A�m�KĨ��I#zV�l5���b8�V�=[��j���Q��bz�Y��bz��W[\rw�ES��\Z��r��C��f[�\\�\Z�k��\Z�뙭��ꚷ���zb뾱�X5V׸Rġ��s����y�-���Z]���[��1Ѯ�.9}�V�����P���YIk-ndk��4���l�k�G�B���vg5����P��;kQ5�@�{(NW��g\rz�PF�\\\rw^���٢fV������8��,��t>@8��^��K켼�2��\'V���z\n��&�N��/�h��B�g�\r+s���=�`5�#Z���V9\\�8k�������Xu��\Z�ȠND���Z,����K���q�8z�P\'\"�ѫ�T�2z���=\n�p�\\S�|y�\0Ǘwp��)���W�)�E��M�>������M��&/�h��i�8����h����G���\'�;\rP\\�L^�0��w9GH�Vf�S\r�4��#$W3s�[�l��^/=��+��|��^�1��Br��smf���kW�\r�ST���#����̖\0�/��&�sQ\Z?n���̏x��f�D�W{q���4A��P*~䏩y�o�mR�c�!����ҰXm�N�g����	F}��S����FpM\"�l�����Ey�>1Zs�\"\\�j��F>��/Sy�>Q�6�wx;i��a�G����R9�k������oilH�`� ����nT���G���y�`D0�e�9태*,_}��!Q�\Z0|����9o�X&�����Ʒ���p��&b��������C�֦��u���<�\0���p8�>�ݹ��3S���;��=�#�I��������^�h��,KZ2�J��n.�<Q�5o`�g�q��[rҫ���yI\n�V��a/^�B����OpO�܊GA��)�t\\\'�Opl�N��q=	<a��&�3��&�^���;X�q�`κ�-[��	Z����i?�z8�J>�_~�;�\r\'�GF%�͖��U8�A���W�.g�7��WJp�P�#�8A������i���=[)2������\n\"\\5��F��^��zԧ7�y�0/)�a���oa�Z-�^�<���)�k2|a�Oc��r�~�񼍪�=��R~\'n���h9G�ce���Ƞ� �����,O~�0<���_�=[5<q1<�0\'�ľ�E*�w�w�%u�q����d��)9)�<u.������OZ^���ll�Xg\n�q��W�)<�o��^F�{Z�~��Z���������9��O�n�:��K��U��<����<m�g��x������ɡ��*ζ�s�6�\Z9q�r|Z%>S�D���T�ޣK���k#�F�8k���ڍhҙ�aJ�(�7��x��jHeX�-�g�S�� L!}�7�o�=	<���7��!�ZY�%����g�Ϋ�����9^����\\�3Ng��I��]��T������zJK\\̴��o	�D#�Ա�\\��];4�K��-4&N\'�w�PO�4.����i\Z6\rU6|ұi:\"�����N�	���KFC�8�?1��<�K)MK����>b�)o��^`�)o��~^�i�(�3t�U��^s}�a(`�c�H0<�����7v�`��㸞fͧ[J��ܑy�Dx.�Z��Kn���[=G��L�\"�n)��	Ŝa��G���e��ME 8��i}�L��{�KT�6��\'\r����f�>̛9���c�g�Xj�u��v��~����k$�cK�&���cJ��{��$���\r��K�x�O���:D�9\r�&���vn�x7~��s\ZEq�\'�i��8�`��m I���C����3��|z`�`Ӽg���VIV������(ᗛ��+�su���#\r��+�����C�o�\'��<��5!B�np1�K�)�;�%���i�G]�˳�%)7�>��.��+.[m{�4�/��	�e�j��˗%�KY�[�\ZX�3kԥ�ʤ��;U{|���!�u�i�������5\\Ć?	O�>ó��h�X�2U����8(yἎ�p�H��,�������g�P��C�|���r�i���1��;��dwo��-q[�%�\r�lH�ِ�-�l	\\G�:����\rn�p-e#~�W�6?�\r9Ԓ��W�:�x��b�q4߫[�L>��k˿O������a�����e���쁰�i��f���=6{ l�@�쁰�a��f]]?�1R��znқQe�/�B+�f0�6�c��(��\0F<�a'),(105181,1,'-\0\0\Z\0\0x���J�@�?o�!x�1iZ��)��zzBK�TM,}m��?�[�M[J/A�ݙ����|rB�+��X2杂	rn8\'�+݁49C�G��<��<p!TG\\��3N�q�+��R|K�K#��S��I���=�%���̐�FV0�=��i���ݖk����8\'�����n��������ٱS6�fXJ�����0�{��{D����V�����o=�Nu����܏��V�z\'�s���̼��fU���\nL�@�Qlb[�\Zy��˯�٠b���T�� \"�_ם:�fUK�sW��]�('),(105181,2,'�\0\0\0�\0\0x�����@�?[�w{��\n�y�\rZ���!<�7�ό[B��Yt�����gj9����@�\r9CZ������P?��r�	cښ��2�A]�[�U��w���P�a#4!���0�7�`-4qI2�i������ך޻w��7zs��s�ny����Ζυ�\r�����U�����l��j�4�mǳSU���k}V����>�qH�5�u�u�+w��ypf䉀'),(105291,-2,'0'),(105291,-1,'0'),(105291,0,'\0\0�p\0\0x��]�n$�������]�܁�3�-_|��BIUZ�RI�J������d�� ��9�n�2�#�A2�d��O�\'��M<���$���x/�N<�����A4�b�~~Rw��J]ߩ�Gqw�-�%�ŏ\n5��~g�/�ϊ�Q<��ayqW��R���_ą�V�����o*�#�5[�T�Nc^�}}�U]ݫ�:���r�;x�	�o*嵺r\04�g���+K����^_�=�a9ɱqyҿ�@�\rj��I��A]{�A��|�gļ]*���Oo��|�P�q�G��\r������9�ܼ:�,W`��o�ly�Lk��v�ߏ�?��G�B�5�|߂e���s]��������ow�[��Lk>C�_(�\'��+��	�R�q~�\0�t9Ѫ�����/B�:t=w�]�-��斫�[��UܝB����*�^��j�~���c5���{T詚{\\�=)�\\�=�➡�l������_�{�ǈ�i�F���QJ��$�|Q�_���.UM���~��]�3��Q�?�rQv�շ����sV׾�o��h���������/ANC���g���%���������}����������\'��c>i�H���������Ϯ������!&��~K�,��ߵ�v�{�,��\'G�G�(o:W\\!��Ϳ���O�n�~�\0����6L�ְ5� ��8�_\\�(���h��eF�{�����8L�$06�zJ���K�Z��\"[:�Ҩ.�*�2W_ŕ��4j��J��u�ف���ʹ.t���\r�F��6kO�R�jZ3xT��F��Wh�|Q<A{W�J����D�l���[a��<�T�kM��8ق�ZP�Ak��5Q4�s�K��Qe��wzT���Eq�\\��Խ��]�ӫ(v���J�E���n�ܑg*iɬ�g��R�9�S<�����a�0��p��]V\'����G�����#�ss��s�7��JC�g��L�?xD[��ոGt��F��j.�F=b���jЯL���XA�$�et=w��PF�s�Uܜ��v7�S4�[�����Wqs>G��Uܩ��J��x��_���p���j��J���8���K��õ�|�Oq�4v��j���%���Kc���{���=x`Q������u�H�S�;Xz���V{����b���mL����ӄ\n�Rװ�u����&��X-�S$D�S��\Z�l�Gh�[�9�	�si�<-ʗ�\"�N]ѱ��e�#ܝ����cc>�1Oƞ7.���ܩ�U�����S�j;���x::���C��hS�JO�Y���H�&u����{,�{�^�<:�\n�p��~�#����A-�z�+a�6C[���T)�^���:�\r�9[���%>f��yΥ����_�g�0c�˩S�W��A~x�a�;�*A�VNM���H_z5���:��cF�Q_���v37�����!s.�R�x�]�:Xϛ�>K.]����v��`ƜԖ=���\Z�h�1ĺz��\nz�����9Lʂ���{�[�b��=�]a�GH��i�\'?)K?@n؛�f}fJ�O���y�닳���n��\nc�TJ�������V��\\M��Kk�FĴ�4��7�?ƽ���~z�ou��CF\n�1�~B�<��5�\rÛ�J�ߡ<�7�;&V֟Z`�(�R�*6��>v/��=ڷ���O�Ty?;1}b�zĥ\n�2Uy���Ōi�L�}�՛>��u�X��>V|\r��f����2��/��ߠ���v.�sX��\n�X���bW�ݿ� �M��<�r��x�U�^���qGHe-a�smVG�fD�H��Mv5�B�R2}L\r[�r~��*�J�f�r~%�*���r�r~m�*w���\n��j�U�+�����d�<T*�+��+�Vy�TV(�U�S��(��h�>n��g�%�e�͜8�E���c~�����֥\r�0:���R����q�ȫs�M��<<��+8w���\n%�e����=����nQve9M��+�F�y�\'���K�5���]ǓM2J0��,�j�S����e%{�!�����{�e�;�w�����!�\r��K7�E�:��̶��r�y��Wl�j�KN\\Y�yZ��4��젅m�Թ��t�^��z�WXe8��Z�#D{x*w�X���v!]�*����q�|���Z��eI�c:\\u���\'Ӌ��)u�=���\r�Üק�j�\n�?%�9y��wc��g��R}���	֦��J�u����\Z;N�֮M�(��Z���!)uY�.+��q$��V�����X�R�*ԻJ�|<I���}�z>��ԇ\n��R=WR�c��X�>�V�*ԧ���p��c�(�)�r�acf<�t�|�b�q;&%4r����Se<XB{�wg�(���4�0�]A=����4gЇo�w�=���}���~k�dp2����%�u����Ѹ�2��\r�G��� :6O�A����\rk���p6j�5{�܍��]��0���,�s�����Y�q�;�ڸ�}[5(^ov5ʕM:[�~&��g�V��5���zb�^:[����5� q(k�R;�Κc&��p�����ڻu�3��ے�w�lٸ�\0\n585�KZ�q#[+m`!N�s�o��]\n�(�ڝ�\0�s�6@q�G5�9T�8[uΞ\r؝CY�r5���ɠf��Y����S㽎�>��\0e���#��y�5��\'֞��z��M~�_�9��\r��KVsp��{��Y�G�р�r�.�q�>8�#���!��̨5�A��W�X>�#�/���y��B��Ơ&rc�ԇtg(\\�x][��|y�Ǘw�p�������+��E��M�>�����2�SY�lt�E8����>�L�2��fF�)���F�`d��<��$W+s�S\r�)�$H�f�d�hٺ��Qz0�Z8d!����qc0��8䐨smfv��kW-��Sl?�g� o3[<��G��Gi��i�e~��D>�g�&���̼FF��C��9P8��Q���Y[�Q��X1l-���&j+Mf>�$�G`2��a���N	�σ���L�)�������q��gfk~^4�3W<R&�|�ڤ��3�j�x��̘,+?sn���AZ[���]Ġ|~��bCf�E�����g�~] ���v~�ь`0��x�`�Z�#��R5�����/�&�1����\Z߆[�����k\"&�~���y���~�5ִ8~U��p����p��\n���۝//��1E|�1��|�g�bD��J��}.��q�m6��`�bO�Ui��_˶w�9�kX��Uv<7�O��~n�v^�����΋w��C���S77�QPot�!=�ѝ�\';��z�K鹞>y��6��ӻ6�^���[ص��bN��[���>��z~<q��}��hN�[N��Z�͕ȟ^x\0����3��]όox;�T�P���F�iU�F5�g�)�������\"�5��F�,�ޜ�z4Ou����p��>}���l���Oʸ\Z>Y�\'|q��c,��r�x�6���p�K�;i+�OG�<�3,{��`�:�I���<c�|$��Y|��}k�����2>��dc�<�W��ӗ�PXR��Μ��!�{9%�⟲��W��?\Z(i���98e���7s�C׽�����}~��|bE2\n|�u��83���غ�ӗў���n��ZK��Uię�9��3�\\Nɫ��c����̘���-3���(aˌ��2J�2c��џB����s-˧N�(�Z?�{+�/��G��2\ZY_������yE������bz�S�\'���!I�(˂oC=���War�	|��Q��A[��b�եX�_x���8u8\Zat�+�-͕~\n��>�\'���)�ʡSV}��>ٞ���2����O�\\���\\괯�\\�������h�;t\Z�Rw�4�MC�\r�tl��Hc�@�V�S�/h��>n���o(�Ujӧ��a��:YL��}�:L����:�K�M�>�3�c���\n�>�0T0Y���a$��G�3��naO��<�f-�[*�a-ɾ�\"~rb��ϡ�����7f�(>���-E)�R��>�9�I�1w�M�j�,NG 8��{�ʘ]��KT�6U|�g�����g�=�9��ԩ�	z,=;���o��Q�F�>�\Z�p��߸��<pL��|�~I�ߍWp�;\\��o�;���!b��kRZ-}���̀ӷ����QW��?�#<��t��3��^Kh˺|B�u��>{`��`�\'��1��dYC$r����DXncl_�?y\'\rOi9}]�\Z��\Z}�>�\'����Kzv�k�y^\nO�ފ�mB�\"/���>��\\>}X��r����O��ek|/��զ	�>A��W�{���e�>�R��v(	+^vϺ6]���gSŞ>�s2��fܴ���ſ��5\\Ág	�}�{���ֱ�5uW��^��c#�5j4����<b�������8��K��<ߝjE%&����������N��7z�ז�-��XI %��8%��Ȗ�u�#p=��	�@��w0*��\r�����Zr��۹�9�M{��h��\Z�4S��8��\n�S�K��/��@�����xu�{5Ŧ>{ |�@������g���=>{ |�@���Y_�Of������vV�������c�L0���e��-(��\0���1'),(105291,1,'�\0\06	\0\0x��V�NB1_M��B�S8$�\Z�@��\\���\n~�?p���%��F{�N����\r�8C-�0�%,1�;�b�)np	�kT8��3E��}�N�w�6���r�B8\'��X�Y���.狸�7���f���\Z(�iP(�����#�cZ����|��\r�W�q���;�;�~g���fE]�����|�ܝ���#0�{�Ի�=����a�y�&�w�O��=�m�����<*�xc�C�9b�>�\r�$oX�gVۍ�W���7�������c��,�j�M0N�8�	\n�L��X���x��G�5����T��lȤ���S����1.G6\r��9��&��jI�|���p��;�0j�[��8s�V\'�%�0W�wB��WotB��j��@5֍^[���źЫ\'�Ӫ9��d�#3U�A�9�m�&yTE����6���r�O���;���!M'),(105291,2,'�\0\0\0�\0\0x�����@�?[�w{��\n�y�\rZ���!<�7�ό[B��Yt�����gj9����@�\r9CZ������P?��r�	cښ��2�A]�[�U��w���P�a#4!���0�7�`-4qI2�i������ך޻w��7zs��s�ny����Ζυ�\r�����U�����l��j�4�mǳSU���k}V����>�qH�5�u�u�+w��ypf䉀');
/*!40000 ALTER TABLE `player_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_shugo_sweep`
--

DROP TABLE IF EXISTS `player_shugo_sweep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_shugo_sweep` (
  `player_id` int(11) NOT NULL,
  `free_dice` int(10) NOT NULL DEFAULT 0,
  `sweep_step` int(10) NOT NULL DEFAULT 0,
  `board_id` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_shugo_sweep`
--

LOCK TABLES `player_shugo_sweep` WRITE;
/*!40000 ALTER TABLE `player_shugo_sweep` DISABLE KEYS */;
INSERT INTO `player_shugo_sweep` VALUES (105181,5,100,1),(105193,5,0,1),(105291,5,0,1),(105325,5,0,1);
/*!40000 ALTER TABLE `player_shugo_sweep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_skill_skins`
--

DROP TABLE IF EXISTS `player_skill_skins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_skill_skins` (
  `player_id` int(11) NOT NULL DEFAULT 0,
  `skin_id` int(11) NOT NULL DEFAULT 0,
  `remaining` bigint(22) DEFAULT 0,
  `active` int(1) DEFAULT 0,
  PRIMARY KEY (`player_id`,`skin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_skill_skins`
--

LOCK TABLES `player_skill_skins` WRITE;
/*!40000 ALTER TABLE `player_skill_skins` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_skill_skins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_skills`
--

DROP TABLE IF EXISTS `player_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_skills` (
  `player_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `skill_level` int(3) NOT NULL DEFAULT 1,
  PRIMARY KEY (`player_id`,`skill_id`),
  CONSTRAINT `player_skills_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_skills`
--

LOCK TABLES `player_skills` WRITE;
/*!40000 ALTER TABLE `player_skills` DISABLE KEYS */;
INSERT INTO `player_skills` VALUES (105181,40,1),(105181,103,1),(105181,106,1),(105181,114,1),(105181,154,1),(105181,243,1),(105181,245,1),(105181,246,1),(105181,247,1),(105181,251,1),(105181,253,1),(105181,283,1),(105181,297,1),(105181,302,1),(105181,308,1),(105181,309,1),(105181,310,1),(105181,311,1),(105181,312,1),(105181,313,1),(105181,314,1),(105181,348,1),(105181,364,1),(105181,365,1),(105181,473,1),(105181,474,1),(105181,475,1),(105181,476,1),(105181,477,1),(105181,478,1),(105181,4221,1),(105181,4222,1),(105181,4300,1),(105181,4339,1),(105181,4408,1),(105181,4409,1),(105181,4709,1),(105181,4800,1),(105181,4801,1),(105181,5385,1),(105181,5386,1),(105181,5387,1),(105181,5388,1),(105181,5389,1),(105181,5390,1),(105181,5391,1),(105181,5392,1),(105181,5393,1),(105181,5394,1),(105181,5395,1),(105181,5396,1),(105181,5397,1),(105181,5398,1),(105181,5399,1),(105181,5400,1),(105181,5401,1),(105181,5402,1),(105181,5403,1),(105181,5404,1),(105181,5405,1),(105181,5406,1),(105181,5414,1),(105181,5415,1),(105181,5416,1),(105181,5417,1),(105181,5418,1),(105181,5419,1),(105181,5420,1),(105181,5428,1),(105181,5429,1),(105181,5430,1),(105181,5431,1),(105181,5432,1),(105181,5433,1),(105181,5434,1),(105181,5435,1),(105181,5436,1),(105181,5437,1),(105181,5438,1),(105181,5439,1),(105181,5440,1),(105181,5441,1),(105181,5442,1),(105181,5443,1),(105181,5444,1),(105181,5445,1),(105181,5446,1),(105181,5447,1),(105181,5448,1),(105181,5449,1),(105181,5450,1),(105181,5451,1),(105181,5452,1),(105181,5453,1),(105181,5454,1),(105181,5455,1),(105181,5456,1),(105181,5457,1),(105181,5458,1),(105181,5459,1),(105181,5460,1),(105181,5461,1),(105181,5462,1),(105181,5463,1),(105181,5464,1),(105181,5465,1),(105181,5466,1),(105181,5467,1),(105181,5468,1),(105181,5469,1),(105181,5470,1),(105181,5505,1),(105181,5506,1),(105181,5507,1),(105181,5508,1),(105181,5509,1),(105181,5510,1),(105181,5511,1),(105181,5512,1),(105181,5513,1),(105181,5514,1),(105181,5515,1),(105181,5516,1),(105181,5517,1),(105181,5518,1),(105181,5519,1),(105181,5520,1),(105181,5521,1),(105181,5522,1),(105181,5523,1),(105181,5524,1),(105181,5525,1),(105181,5526,1),(105181,5527,1),(105181,5534,1),(105181,5548,1),(105181,5557,1),(105181,5558,1),(105181,5569,1),(105181,5570,1),(105181,5571,1),(105181,5575,1),(105181,5576,1),(105181,5577,1),(105181,5578,1),(105181,5579,1),(105181,5580,1),(105181,5581,1),(105181,5582,1),(105181,5583,1),(105181,5584,1),(105181,5585,1),(105181,5586,1),(105181,5587,1),(105181,5589,1),(105181,5601,1),(105181,5658,1),(105181,5659,1),(105181,5660,1),(105181,5661,1),(105181,5662,1),(105181,5663,1),(105181,5664,1),(105181,5670,1),(105181,5671,1),(105181,5672,1),(105181,5673,1),(105181,5674,1),(105181,30002,1),(105181,30003,1),(105181,40009,1),(105181,40011,1),(105181,40012,1),(105291,39,1),(105291,40,1),(105291,42,1),(105291,46,1),(105291,49,1),(105291,50,1),(105291,89,1),(105291,132,1),(105291,155,1),(105291,156,1),(105291,159,1),(105291,165,1),(105291,176,1),(105291,209,1),(105291,211,1),(105291,212,1),(105291,213,1),(105291,233,1),(105291,234,1),(105291,235,1),(105291,243,1),(105291,245,1),(105291,246,1),(105291,247,1),(105291,251,1),(105291,253,1),(105291,283,1),(105291,297,1),(105291,302,1),(105291,308,1),(105291,309,1),(105291,310,1),(105291,311,1),(105291,312,1),(105291,313,1),(105291,314,1),(105291,362,1),(105291,363,1),(105291,364,1),(105291,365,1),(105291,366,1),(105291,367,1),(105291,368,1),(105291,369,1),(105291,1614,1),(105291,1615,1),(105291,1684,1),(105291,1699,1),(105291,1814,1),(105291,1815,1),(105291,1816,1),(105291,1817,1),(105291,1818,1),(105291,1819,1),(105291,1820,1),(105291,1821,1),(105291,1822,1),(105291,1823,1),(105291,1824,1),(105291,1825,1),(105291,1838,1),(105291,1839,1),(105291,1840,1),(105291,1841,1),(105291,1842,1),(105291,1843,1),(105291,1844,1),(105291,1845,1),(105291,1846,1),(105291,1847,1),(105291,1848,1),(105291,1849,1),(105291,1850,1),(105291,3888,1),(105291,3889,1),(105291,3890,1),(105291,3891,1),(105291,3892,1),(105291,3893,1),(105291,3894,1),(105291,3895,1),(105291,3912,1),(105291,3913,1),(105291,3914,1),(105291,3915,1),(105291,3916,1),(105291,3917,1),(105291,3918,1),(105291,3919,1),(105291,3920,1),(105291,3921,1),(105291,3922,1),(105291,3935,1),(105291,3936,1),(105291,3937,1),(105291,3938,1),(105291,3951,1),(105291,3952,1),(105291,3953,1),(105291,3954,1),(105291,3955,1),(105291,3956,1),(105291,3957,1),(105291,3958,1),(105291,3959,1),(105291,3977,1),(105291,4004,1),(105291,4005,1),(105291,4012,1),(105291,4013,1),(105291,4037,1),(105291,4038,1),(105291,4039,1),(105291,4040,1),(105291,4041,1),(105291,4042,1),(105291,4043,1),(105291,4044,1),(105291,4045,1),(105291,4046,1),(105291,4047,1),(105291,4048,1),(105291,4049,1),(105291,4050,1),(105291,4051,1),(105291,4052,1),(105291,4053,1),(105291,4054,1),(105291,4055,1),(105291,4056,1),(105291,4057,1),(105291,4058,1),(105291,4059,1),(105291,4060,1),(105291,4061,1),(105291,4062,1),(105291,4063,1),(105291,4064,1),(105291,4065,1),(105291,4066,1),(105291,4067,1),(105291,4068,1),(105291,4069,1),(105291,4070,1),(105291,4071,1),(105291,4072,1),(105291,4073,1),(105291,4074,1),(105291,4075,1),(105291,4076,1),(105291,4077,1),(105291,4078,1),(105291,4079,1),(105291,4080,1),(105291,4081,1),(105291,4082,1),(105291,4083,1),(105291,4084,1),(105291,4085,1),(105291,4086,1),(105291,4087,1),(105291,4088,1),(105291,4089,1),(105291,4090,1),(105291,4091,1),(105291,4092,1),(105291,4093,1),(105291,4094,1),(105291,4098,1),(105291,4099,1),(105291,4100,1),(105291,4101,1),(105291,4106,1),(105291,4108,1),(105291,4110,1),(105291,4112,1),(105291,4114,1),(105291,4116,1),(105291,4118,1),(105291,4120,1),(105291,4122,1),(105291,4124,1),(105291,4126,1),(105291,4127,1),(105291,4128,1),(105291,4129,1),(105291,4130,1),(105291,4131,1),(105291,4132,1),(105291,4133,1),(105291,4150,1),(105291,4151,1),(105291,4170,1),(105291,4171,1),(105291,4172,1),(105291,4173,1),(105291,4174,1),(105291,4175,1),(105291,4176,1),(105291,4177,1),(105291,4178,1),(105291,4179,1),(105291,4180,1),(105291,4181,1),(105291,4203,1),(105291,4204,1),(105291,4205,1),(105291,4206,1),(105291,4207,1),(105291,4208,1),(105291,4209,1),(105291,4210,1),(105291,4211,1),(105291,4212,1),(105291,4213,1),(105291,4214,1),(105291,4215,1),(105291,4216,1),(105291,4217,1),(105291,4218,1),(105291,4219,1),(105291,4220,1),(105291,4646,1),(105291,4709,1),(105291,4778,1),(105291,4779,1),(105291,4780,1),(105291,4783,1),(105291,4800,1),(105291,4801,1),(105291,4870,1),(105291,6726,10),(105291,6773,10),(105291,6836,20),(105291,13703,10),(105291,23185,20),(105291,30002,1),(105291,30003,1),(105291,40009,1),(105291,40011,1),(105291,40012,1);
/*!40000 ALTER TABLE `player_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_titles`
--

DROP TABLE IF EXISTS `player_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_titles` (
  `player_id` int(11) NOT NULL,
  `title_id` int(11) NOT NULL,
  `remaining` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`,`title_id`),
  CONSTRAINT `player_titles_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_titles`
--

LOCK TABLES `player_titles` WRITE;
/*!40000 ALTER TABLE `player_titles` DISABLE KEYS */;
INSERT INTO `player_titles` VALUES (105291,265,0),(105291,266,0),(105291,383,0);
/*!40000 ALTER TABLE `player_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_transform_collections`
--

DROP TABLE IF EXISTS `player_transform_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_transform_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_transform_collections`
--

LOCK TABLES `player_transform_collections` WRITE;
/*!40000 ALTER TABLE `player_transform_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_transform_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_transformation`
--

DROP TABLE IF EXISTS `player_transformation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_transformation` (
  `player_id` int(10) NOT NULL,
  `panel_id` int(5) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_transformation`
--

LOCK TABLES `player_transformation` WRITE;
/*!40000 ALTER TABLE `player_transformation` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_transformation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_vars`
--

DROP TABLE IF EXISTS `player_vars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_vars` (
  `player_id` int(11) NOT NULL,
  `param` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `time` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`player_id`,`param`),
  CONSTRAINT `player_vars_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_vars`
--

LOCK TABLES `player_vars` WRITE;
/*!40000 ALTER TABLE `player_vars` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_vars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_wardrobe`
--

DROP TABLE IF EXISTS `player_wardrobe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_wardrobe` (
  `player_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `slot` int(11) NOT NULL,
  `reskin_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`player_id`,`item_id`),
  CONSTRAINT `player_wardrobe_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_wardrobe`
--

LOCK TABLES `player_wardrobe` WRITE;
/*!40000 ALTER TABLE `player_wardrobe` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_wardrobe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_world_bans`
--

DROP TABLE IF EXISTS `player_world_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_world_bans` (
  `player` int(11) NOT NULL,
  `by` varchar(255) NOT NULL,
  `duration` bigint(11) NOT NULL,
  `date` bigint(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  PRIMARY KEY (`player`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_world_bans`
--

LOCK TABLES `player_world_bans` WRITE;
/*!40000 ALTER TABLE `player_world_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_world_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `players` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `account_id` int(11) NOT NULL,
  `account_name` varchar(50) NOT NULL,
  `exp` bigint(20) NOT NULL DEFAULT 0,
  `recoverexp` bigint(20) NOT NULL DEFAULT 0,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `heading` int(11) NOT NULL,
  `world_id` int(11) NOT NULL,
  `world_owner` int(11) NOT NULL DEFAULT 0,
  `gender` enum('MALE','FEMALE') NOT NULL,
  `race` enum('ASMODIANS','ELYOS') NOT NULL,
  `player_class` enum('WARRIOR','GLADIATOR','TEMPLAR','SCOUT','ASSASSIN','RANGER','MAGE','SORCERER','SPIRIT_MASTER','PRIEST','CLERIC','CHANTER','ENGINEER','GUNNER','ARTIST','RIDER','BARD','PAINTER') NOT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `deletion_date` timestamp NULL DEFAULT NULL,
  `last_online` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `cube_expands` tinyint(1) NOT NULL DEFAULT 0,
  `advanced_stigma_slot_size` tinyint(1) NOT NULL DEFAULT 0,
  `warehouse_size` tinyint(1) NOT NULL DEFAULT 0,
  `mailbox_letters` tinyint(4) unsigned NOT NULL DEFAULT 0,
  `title_id` int(3) NOT NULL DEFAULT -1,
  `bonus_title_id` int(3) NOT NULL DEFAULT -1,
  `dp` int(3) NOT NULL DEFAULT 0,
  `soul_sickness` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `reposte_energy` bigint(20) NOT NULL DEFAULT 0,
  `goldenstar_energy` bigint(20) NOT NULL DEFAULT 0,
  `silverstar_energy` bigint(20) NOT NULL DEFAULT 0,
  `growth_energy` bigint(20) NOT NULL DEFAULT 0,
  `bg_points` int(11) NOT NULL DEFAULT 0,
  `online` tinyint(1) NOT NULL DEFAULT 0,
  `note` text DEFAULT NULL,
  `mentor_flag_time` int(11) NOT NULL DEFAULT 0,
  `initial_gamestats` int(11) NOT NULL DEFAULT 0,
  `last_transfer_time` decimal(20,0) NOT NULL DEFAULT 0,
  `fatigue` int(11) NOT NULL DEFAULT 0,
  `fatigueRecover` int(11) NOT NULL DEFAULT 0,
  `fatigueReset` int(11) NOT NULL DEFAULT 0,
  `joinRequestLegionId` int(11) NOT NULL DEFAULT 0,
  `joinRequestState` enum('NONE','DENIED','ACCEPTED') NOT NULL DEFAULT 'NONE',
  `frenzy_points` int(4) NOT NULL DEFAULT 0 COMMENT 'Upgrade Arcade FrenzyPoints',
  `frenzy_count` int(1) NOT NULL DEFAULT 0,
  `show_inventory` int(1) NOT NULL DEFAULT 1,
  `bonus_buff_time` timestamp NULL DEFAULT NULL,
  `bonus_type` enum('RETURN','NEW','NORMAL') NOT NULL DEFAULT 'NORMAL',
  `wardrobe_size` int(4) NOT NULL,
  `wardrobe_slot` int(11) NOT NULL DEFAULT 2,
  `luna_consume_count` int(11) NOT NULL DEFAULT 0,
  `muni_keys` int(11) NOT NULL DEFAULT 0,
  `luna_consume` int(11) NOT NULL DEFAULT 0,
  `toc_floor` int(11) NOT NULL DEFAULT 0,
  `minion_energy` int(11) NOT NULL DEFAULT 0,
  `last_minion` int(11) NOT NULL DEFAULT 0,
  `minion_function` timestamp NULL DEFAULT NULL,
  `world_play_time` int(11) NOT NULL DEFAULT 0,
  `last_transfo` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_unique` (`name`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `players`
--

LOCK TABLES `players` WRITE;
/*!40000 ALTER TABLE `players` DISABLE KEYS */;
INSERT INTO `players` VALUES (105181,'Elyza',8,'test',5403335636,0,1604.55,1390.22,193.129,70,120010000,0,'FEMALE','ASMODIANS','PAINTER','2026-07-21 21:33:23',NULL,'2026-08-13 18:25:23',1,0,0,0,-1,-1,0,0,89883256,0,0,0,0,0,NULL,0,1,0,0,0,0,0,'NONE',0,0,1,NULL,'NEW',256,0,0,0,0,0,0,0,NULL,0,0),(105291,'Adle',8,'test',5762523081,0,581.051,2438.53,279.901,28,220010000,0,'MALE','ASMODIANS','CLERIC','2026-07-29 21:12:39',NULL,'2026-08-14 20:46:26',10,0,0,0,-1,-1,0,0,95031856,625000000,0,0,0,0,NULL,0,1,0,0,0,0,0,'NONE',32,2,1,NULL,'NEW',256,0,2,0,50,0,0,0,NULL,0,0);
/*!40000 ALTER TABLE `players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_cooldowns`
--

DROP TABLE IF EXISTS `portal_cooldowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_cooldowns` (
  `player_id` int(11) NOT NULL,
  `world_id` int(11) NOT NULL,
  `reuse_time` bigint(13) NOT NULL,
  `entry_count` int(2) NOT NULL,
  PRIMARY KEY (`player_id`,`world_id`),
  CONSTRAINT `portal_cooldowns_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_cooldowns`
--

LOCK TABLES `portal_cooldowns` WRITE;
/*!40000 ALTER TABLE `portal_cooldowns` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_cooldowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `real_item_rnd_bonus`
--

DROP TABLE IF EXISTS `real_item_rnd_bonus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `real_item_rnd_bonus` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `item_obj_id` int(11) NOT NULL DEFAULT 0,
  `stat_name` varchar(50) DEFAULT NULL,
  `stat_val` int(11) DEFAULT NULL,
  `is_fusion` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `real_item_rnd_bonus`
--

LOCK TABLES `real_item_rnd_bonus` WRITE;
/*!40000 ALTER TABLE `real_item_rnd_bonus` DISABLE KEYS */;
INSERT INTO `real_item_rnd_bonus` VALUES (8,105287,'MAXMP',951,0),(9,105287,'BOOST_CASTING_TIME',12,0),(10,105287,'HEAL_BOOST',113,0),(11,105287,'MAGICAL_ACCURACY',317,0),(12,105288,'PHYSICAL_DEFENSE',156,0),(13,105410,'MAGICAL_CRITICAL',175,0),(14,105410,'MAGICAL_ACCURACY',198,0),(15,105410,'EVASION',300,0),(16,105410,'MAGICAL_DEFEND',179,0),(17,105409,'PHYSICAL_ACCURACY',306,0),(18,105409,'PHYSICAL_CRITICAL',249,0),(19,105409,'PARRY',548,0),(20,105409,'MAXHP',1213,0),(21,105227,'PHYSICAL_CRITICAL',346,0),(22,105227,'ATTACK_SPEED',16,0),(23,105227,'PHYSICAL_ATTACK',222,0),(24,105227,'PARRY',442,0);
/*!40000 ALTER TABLE `real_item_rnd_bonus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_variables`
--

DROP TABLE IF EXISTS `server_variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_variables` (
  `key` varchar(30) NOT NULL,
  `value` varchar(30) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_variables`
--

LOCK TABLES `server_variables` WRITE;
/*!40000 ALTER TABLE `server_variables` DISABLE KEYS */;
INSERT INTO `server_variables` VALUES ('auctionProlonged','0'),('auctionTime','1786874700'),('houseMaintainTime','1786917600'),('time','67741');
/*!40000 ALTER TABLE `server_variables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `siege_locations`
--

DROP TABLE IF EXISTS `siege_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `siege_locations` (
  `id` int(11) NOT NULL,
  `race` enum('ELYOS','ASMODIANS','BALAUR') NOT NULL,
  `legion_id` int(11) NOT NULL,
  `occupy_count` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `siege_locations`
--

LOCK TABLES `siege_locations` WRITE;
/*!40000 ALTER TABLE `siege_locations` DISABLE KEYS */;
INSERT INTO `siege_locations` VALUES (1011,'BALAUR',0,1),(1014,'BALAUR',0,0),(1016,'BALAUR',0,0),(1017,'BALAUR',0,0),(1018,'BALAUR',0,0),(1019,'BALAUR',0,0),(1511,'BALAUR',0,0),(1512,'BALAUR',0,0),(1513,'BALAUR',0,0),(1514,'BALAUR',0,0),(1515,'BALAUR',0,0),(1516,'BALAUR',0,0),(1517,'BALAUR',0,0),(1518,'BALAUR',0,0),(1519,'BALAUR',0,0),(1521,'BALAUR',0,2),(1921,'BALAUR',0,1),(1931,'BALAUR',0,0),(1932,'BALAUR',0,0),(1933,'BALAUR',0,0),(1934,'BALAUR',0,0),(5021,'BALAUR',0,1),(5022,'BALAUR',0,1),(5023,'BALAUR',0,1),(5024,'BALAUR',0,1),(5025,'BALAUR',0,1),(5026,'BALAUR',0,1),(5027,'BALAUR',0,1),(5028,'BALAUR',0,1),(5029,'BALAUR',0,1),(5030,'BALAUR',0,1),(5031,'BALAUR',0,1);
/*!40000 ALTER TABLE `siege_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `siege_spawns`
--

DROP TABLE IF EXISTS `siege_spawns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `siege_spawns` (
  `spawn_id` int(10) NOT NULL,
  `siege_id` int(10) NOT NULL,
  `race` enum('ELYOS','ASMODIANS','BALAUR') NOT NULL,
  `protector` int(10) DEFAULT 0,
  `stype` enum('PEACE','GUARD','ARTIFACT','PROTECTOR','MINE','PORTAL','GENERATOR','SPRING','RACEPROTECTOR','UNDERPASS') DEFAULT NULL,
  PRIMARY KEY (`spawn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `siege_spawns`
--

LOCK TABLES `siege_spawns` WRITE;
/*!40000 ALTER TABLE `siege_spawns` DISABLE KEYS */;
/*!40000 ALTER TABLE `siege_spawns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skill_motions`
--

DROP TABLE IF EXISTS `skill_motions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skill_motions` (
  `motion_name` varchar(255) NOT NULL DEFAULT '',
  `weapon_type` varchar(255) NOT NULL,
  `off_weapon_type` varchar(255) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `attack_speed` int(11) NOT NULL,
  `race` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`motion_name`,`skill_id`,`attack_speed`,`weapon_type`,`off_weapon_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill_motions`
--

LOCK TABLES `skill_motions` WRITE;
/*!40000 ALTER TABLE `skill_motions` DISABLE KEYS */;
/*!40000 ALTER TABLE `skill_motions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spawns`
--

DROP TABLE IF EXISTS `spawns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spawns` (
  `spawn_id` int(10) NOT NULL AUTO_INCREMENT,
  `npc_id` int(10) NOT NULL,
  `npc_name` varchar(50) NOT NULL DEFAULT '',
  `map_id` int(10) NOT NULL,
  `pool_size` int(5) NOT NULL DEFAULT 1,
  `anchor` varchar(100) DEFAULT NULL,
  `handler` enum('RIFT','STATIC') DEFAULT NULL,
  `spawn_time` enum('ALL','DAY','NIGHT') NOT NULL DEFAULT 'ALL',
  `walker_id` int(10) NOT NULL DEFAULT 0,
  `random_walk` int(10) NOT NULL DEFAULT 0,
  `static_id` int(10) NOT NULL DEFAULT 0,
  `fly` tinyint(1) NOT NULL DEFAULT 0,
  `respawn_time` int(10) NOT NULL DEFAULT 0,
  `last_despawn_time` timestamp NULL DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `author` varchar(50) NOT NULL DEFAULT 'system',
  PRIMARY KEY (`spawn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spawns`
--

LOCK TABLES `spawns` WRITE;
/*!40000 ALTER TABLE `spawns` DISABLE KEYS */;
/*!40000 ALTER TABLE `spawns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `special_landing`
--

DROP TABLE IF EXISTS `special_landing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `special_landing` (
  `id` int(2) NOT NULL,
  `type` enum('SPAWN','DESPAWN') NOT NULL DEFAULT 'DESPAWN'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `special_landing`
--

LOCK TABLES `special_landing` WRITE;
/*!40000 ALTER TABLE `special_landing` DISABLE KEYS */;
/*!40000 ALTER TABLE `special_landing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveys`
--

DROP TABLE IF EXISTS `surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `surveys` (
  `unique_id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_count` decimal(20,0) NOT NULL DEFAULT 1,
  `html_text` text NOT NULL,
  `html_radio` varchar(100) NOT NULL DEFAULT 'accept',
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `used_time` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`unique_id`),
  KEY `owner_id` (`owner_id`),
  CONSTRAINT `surveys_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveys`
--

LOCK TABLES `surveys` WRITE;
/*!40000 ALTER TABLE `surveys` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `id` int(5) NOT NULL,
  `task_type` enum('SHUTDOWN','RESTART') NOT NULL,
  `trigger_type` enum('FIXED_IN_TIME') NOT NULL,
  `trigger_param` text NOT NULL,
  `exec_param` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `towns`
--

DROP TABLE IF EXISTS `towns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `towns` (
  `id` int(11) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 1,
  `points` int(10) NOT NULL DEFAULT 0,
  `race` enum('ELYOS','ASMODIANS') NOT NULL,
  `level_up_date` timestamp NOT NULL DEFAULT '1970-01-01 06:00:01',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `towns`
--

LOCK TABLES `towns` WRITE;
/*!40000 ALTER TABLE `towns` DISABLE KEYS */;
INSERT INTO `towns` VALUES (1001,1,0,'ELYOS','1970-01-01 06:00:01'),(1002,1,0,'ELYOS','1970-01-01 06:00:01'),(1003,1,0,'ELYOS','1970-01-01 06:00:01'),(1004,1,0,'ELYOS','1970-01-01 06:00:01'),(1005,1,0,'ELYOS','1970-01-01 06:00:01'),(1006,1,0,'ELYOS','1970-01-01 06:00:01'),(1007,1,0,'ELYOS','1970-01-01 06:00:01'),(1008,1,0,'ELYOS','1970-01-01 06:00:01'),(1009,1,0,'ELYOS','1970-01-01 06:00:01'),(1010,1,0,'ELYOS','1970-01-01 06:00:01'),(1011,1,0,'ELYOS','1970-01-01 06:00:01'),(1012,1,0,'ELYOS','1970-01-01 06:00:01'),(1013,1,0,'ELYOS','1970-01-01 06:00:01'),(1014,1,0,'ELYOS','1970-01-01 06:00:01'),(1015,1,0,'ELYOS','1970-01-01 06:00:01'),(1016,1,0,'ELYOS','1970-01-01 06:00:01'),(1017,1,0,'ELYOS','1970-01-01 06:00:01'),(1018,1,0,'ELYOS','1970-01-01 06:00:01'),(1019,1,0,'ELYOS','1970-01-01 06:00:01'),(1020,1,0,'ELYOS','1970-01-01 06:00:01'),(1021,1,0,'ELYOS','1970-01-01 06:00:01'),(1022,1,0,'ELYOS','1970-01-01 06:00:01'),(1023,1,0,'ELYOS','1970-01-01 06:00:01'),(1024,1,0,'ELYOS','1970-01-01 06:00:01'),(1025,1,0,'ELYOS','1970-01-01 06:00:01'),(2001,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2002,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2003,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2004,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2005,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2006,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2007,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2008,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2009,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2010,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2011,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2012,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2013,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2014,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2015,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2016,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2017,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2018,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2019,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2020,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2021,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2022,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2023,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2024,1,0,'ASMODIANS','1970-01-01 06:00:01'),(2025,1,0,'ASMODIANS','1970-01-01 06:00:01');
/*!40000 ALTER TABLE `towns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transformations`
--

DROP TABLE IF EXISTS `transformations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transformations` (
  `player_id` int(11) NOT NULL,
  `transformation_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `grade` varchar(11) NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`player_id`,`transformation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transformations`
--

LOCK TABLES `transformations` WRITE;
/*!40000 ALTER TABLE `transformations` DISABLE KEYS */;
/*!40000 ALTER TABLE `transformations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_reward`
--

DROP TABLE IF EXISTS `web_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_reward` (
  `unique` int(11) NOT NULL AUTO_INCREMENT,
  `item_owner` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_count` decimal(20,0) NOT NULL DEFAULT 1,
  `rewarded` tinyint(1) NOT NULL DEFAULT 0,
  `added` varchar(70) DEFAULT '',
  `received` varchar(70) DEFAULT '',
  PRIMARY KEY (`unique`),
  KEY `item_owner` (`item_owner`),
  CONSTRAINT `web_reward_ibfk_1` FOREIGN KEY (`item_owner`) REFERENCES `players` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_reward`
--

LOCK TABLES `web_reward` WRITE;
/*!40000 ALTER TABLE `web_reward` DISABLE KEYS */;
/*!40000 ALTER TABLE `web_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weddings`
--

DROP TABLE IF EXISTS `weddings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weddings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `player1` int(11) NOT NULL,
  `player2` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `player1` (`player1`),
  KEY `player2` (`player2`),
  CONSTRAINT `weddings_ibfk_1` FOREIGN KEY (`player1`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `weddings_ibfk_2` FOREIGN KEY (`player2`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weddings`
--

LOCK TABLES `weddings` WRITE;
/*!40000 ALTER TABLE `weddings` DISABLE KEYS */;
/*!40000 ALTER TABLE `weddings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'al_server_gs'
--

--
-- Dumping routines for database 'al_server_gs'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-15 22:28:53
